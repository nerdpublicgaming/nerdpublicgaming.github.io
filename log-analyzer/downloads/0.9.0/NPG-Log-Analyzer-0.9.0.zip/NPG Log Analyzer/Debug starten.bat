@echo off
rem Startet den NPG Log Analyzer mit sichtbarem Konsolenfenster (Fehlermeldungen sichtbar).
cd /d "%~dp0"
"runtime\python.exe" "app\main.py"
pause
