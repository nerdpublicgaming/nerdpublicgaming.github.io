"""NPG Log Analyzer – Starter (der Programmcode liegt kompiliert daneben)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import npg_main
npg_main.main()
