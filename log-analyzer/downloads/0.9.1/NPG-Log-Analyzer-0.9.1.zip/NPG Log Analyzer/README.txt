NPG Log Analyzer – 0.9 Beta
===========================
Fan project by NerdPublic Gaming. Not an official product of ArenaNet or NCSOFT.
Download, news and "report a bug": https://nerdpublicgaming.github.io/log-analyzer/
(Deutsche Anleitung: LIES MICH.txt)

Language
--------
The program follows your Windows language on first start. Switch any time with
DE | EN at the bottom left of the sidebar or in Settings -> About & updates.

Getting started
---------------
1. Extract the ZIP completely (e.g. to Documents\NPG Log Analyzer).
2. Double-click "NPG Log Analyzer.exe". It opens in its own window.
   On first start Windows may show "Windows protected your PC" (the EXE is not
   signed) -> "More info" -> "Run anyway".
3. If nothing happens: run "Debug starten.bat" – it shows error messages.

What the program needs
----------------------
- Windows 10/11 with Microsoft Edge (pre-installed). Edge is used for the window
  and for printing PDFs. Python is already included in the "runtime" folder.
- GW2: arcdps + Elite Insights, so that the .html reports are next to the .zevtc
  files in the arcdps.cbtlogs folder. Alternatively paste dps.report links.
  If your arcdps folder is somewhere else: Settings -> arcdps folder.
- Internet for the Wingman comparison values, dps.report, weekly clears and the
  update check. Everything else runs locally on your PC.

What the program does
---------------------
- Analyze evening: all attempts, Wingman comparison, damage + share, development
  per attempt, two PDFs and a Discord text. Filter by raids / strikes / fractals.
- Players & badges, bosses (kill times over the weeks), history, comparison of
  two logs, golem training (personal bests, history, benchmark targets).
- Live meter (see below), OBS overlay, CSV export.
- Lost Ark (preview): analysis from LOA Logs; comparison values from lostark.bible
  only by copy/paste.
Note: boss, skill and mechanic names come from your logs – with a German game
client they are German, with an English client English.

Live meter (second monitor)
---------------------------
1. Nexus and arcdps must be running in the game.
2. Copy "nexus-addon\NPG_LiveBridge.dll" into the folder  <Guild Wars 2>\addons\
   (close the game first), then in game open Nexus (Ctrl + O) -> Addons ->
   load "NPG Live Bridge". Details (German): nexus-addon\LIES MICH.txt
3. In the program: sidebar -> Live meter ("Own window" button for the second monitor).
   Click a name to see the skills, tab "Boons" shows the boon table.

Updates
-------
- On start the program checks the NPG homepage for a newer version. It only
  installs when you click "Update now". Settings and history are kept. If a new
  version doesn't start, the previous one is restored automatically.
  Settings -> About & updates (channel beta/stable, turn the check off).
- The live meter tells you about new versions of the DLL; you replace it yourself.

Report a bug
------------
Settings -> About & updates -> "Create bug report". A ZIP file is created on your
desktop (log, version, Windows version; keys/tokens masked).
Where to send it is on the download page.

Where things are stored
-----------------------
- Settings, history and cache: %APPDATA%\NPG Log Analyzer
- PDFs: Documents\NPG Log Analyzer by default (changeable in the settings)

Support
-------
Like the program? "Buy me a coffee" in the sidebar opens my PayPal. Thank you!

Uninstall: delete the program folder, optionally also %APPDATA%\NPG Log Analyzer.
