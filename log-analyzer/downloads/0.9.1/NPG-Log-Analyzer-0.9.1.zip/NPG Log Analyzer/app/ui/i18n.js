/* NPG Log Analyzer – Sprache Deutsch/Englisch für die Oberfläche.
   Deutsch ist die Grundsprache. Bei Englisch übersetzt ein Beobachter jeden Text, sobald er auf dem Bildschirm erscheint
   (gleiche Regeln wie core/i18n.py: „{}“ = eingesetzter Wert, „{1}“ = Wert Nr. 1, „{1|s}“ = „s“ wenn Wert 1 nicht leer). */
(function () {
  let data = { lang: "de", dict: {} };
  try {
    const x = new XMLHttpRequest();
    x.open("GET", "/api/i18n", false); x.send();
    if (x.status === 200) data = JSON.parse(x.responseText);
  } catch (e) {}
  const EN = data.lang === "en";
  window.NPG_LANG = data.lang;
  window.LOC = EN ? "en-GB" : "de-DE";
  window.DEC = EN ? "." : ",";
  window.UNITS = EN ? { Bio: "T", Mrd: "B", Mio: "M", Tag: "d", Std: "h" } : { Bio: "Bio", Mrd: "Mrd", Mio: "Mio", Tag: "T", Std: "Std" };
  document.documentElement.lang = data.lang;
  const LET = /[A-Za-zÄÖÜäöüß]{2}/;
  const TOK = /\{(\d*)(?:\|([^}]*))?\}/g;
  const norm = (s) => s.replace(/\s+/g, " ").trim();
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const exact = new Map(), strip = new Map(), pats = [], cache = new Map(), inline = [];
  const NONL = /^[^A-Za-zÄÖÜäöüß]+|[^A-Za-zÄÖÜäöüß]+$/g;
  const core = (s) => s.replace(NONL, "");
  for (const [rx, rep] of (data.dict || {}).__inline__ || []) inline.push([new RegExp(rx, "g"), rep]);
  for (const [k0, v] of Object.entries(data.dict || {})) {
    if (k0.startsWith("__")) continue;
    const k = norm(k0);
    if (!k.includes("{}")) { exact.set(k, v); const sk = core(k); if (sk && sk !== k && !strip.has(sk)) strip.set(sk, core(v)); continue; }
    const lit = k.split("{}").join("");
    const letters = lit.replace(/[^A-Za-zÄÖÜäöüß]/g, "");
    if (letters.length < 3 || ["bei", "und", "mit", "von", "vom", "aus", "für", "nach", "oder"].includes(letters.toLowerCase())) continue;
    const plural = new Set([...v.matchAll(/\{(\d+)\|/g)].map((m) => Number(m[1])));
    const parts = k.split("{}");
    const need = parts.reduce((a, b) => (b.length > a.length ? b : a), "");
    let rxs = "^";
    parts.forEach((p, i) => {
      rxs += esc(p);
      if (i < parts.length - 1) rxs += plural.has(i) ? "([a-zäöüß]{0,3})" : /[A-Za-zÄÖÜäöüß]$/.test(p) ? "((?![a-zäöüß]).*?)" : "(.*?)";
    });
    pats.push({ len: lit.length, need, rx: new RegExp(rxs + "$", "s"), v });
  }
  pats.sort((a, b) => b.len - a.len);
  function fill(tpl, groups, depth) {
    let n = 0;
    return tpl.replace(TOK, (_, idx, plural) => {
      const i = idx !== "" ? Number(idx) : Math.min(n++, groups.length - 1);
      const g = groups[i] ?? "";
      if (plural !== undefined) return g.trim() ? plural : "";
      return g.trim() && depth < 3 ? one(g, depth + 1) : g;
    });
  }
  function match(t, depth) {
    if (exact.has(t)) return exact.get(t);
    for (const p of pats) {
      if (p.need && !t.includes(p.need)) continue;
      const m = p.rx.exec(t);
      if (m) return fill(p.v, m.slice(1), depth);
    }
    return null;
  }
  function one(s, depth = 0) {
    if (!s || !LET.test(s)) return s;
    const lead = s.match(/^\s*/)[0], trail = s.match(/\s*$/)[0];
    const t = norm(s);
    let r = match(t, depth);
    if (r !== null) return lead + r + trail;
    const m = t.match(/^([^A-Za-zÄÖÜäöüß]*)(.*?)([^A-Za-zÄÖÜäöüß]*)$/s);
    if (m && m[2] && m[2] !== t) {
      r = match(m[2], depth);
      if (r === null && strip.has(m[2])) r = strip.get(m[2]);
      if (r !== null) return lead + m[1] + r + m[3] + trail;
    }
    if (depth < 3) for (const sep of [" · ", " – ", "; ", ", ", ": "]) {
      if (t.includes(sep)) {
        const parts = t.split(sep), neu = parts.map((x) => one(x, depth + 1));
        if (neu.some((x, i) => x !== parts[i])) return lead + neu.join(sep) + trail;
      }
    }
    return s;
  }
  function tr(s) {
    if (!EN || typeof s !== "string") return s;
    if (cache.has(s)) return cache.get(s);
    let r = one(s);
    for (const [rx, rep] of inline) r = r.replace(rx, rep);
    if (cache.size < 20000) cache.set(s, r);
    return r;
  }
  function trText(s) {   // mehrzeilig (Zwischenablage, Hinweise)
    if (!EN || !s) return s;
    return s.split("\n").map((line) => {
      const m = line.match(/^(\s*(?:[-*•>]+\s*)?)(.*?)(\s*)$/);
      const body = m[2].includes("**") ? m[2].split("**").map(tr).join("**") : tr(m[2]);
      return m[1] + body + m[3];
    }).join("\n");
  }
  window.tr = tr; window.trText = trText;
  if (!EN) return;
  const ATTRS = ["title", "placeholder", "alt", "aria-label"];
  const SKIP = new Set(["SCRIPT", "STYLE", "TEXTAREA", "CODE"]);
  function doNode(node) {
    if (node.nodeType === 3) {
      const p = node.parentNode;
      if (!p || SKIP.has(p.nodeName) || (p.closest && p.closest("[data-notr]"))) return;
      const v = node.nodeValue, n = p.nodeName === "PRE" ? trText(v) : tr(v);
      if (n !== v) node.nodeValue = n;
      return;
    }
    if (node.nodeType !== 1 || node.nodeName === "SCRIPT" || node.nodeName === "STYLE" || node.hasAttribute("data-notr")) return;
    for (const a of ATTRS) { const v = node.getAttribute(a); if (v) { const n = tr(v); if (n !== v) node.setAttribute(a, n); } }
    if (node.nodeName === "INPUT" && (node.type === "button" || node.type === "submit") && node.value) node.value = tr(node.value);
    if (node.nodeName === "OPTION" && node.label !== node.textContent) { /* Text-Knoten werden unten übersetzt */ }
    if (SKIP.has(node.nodeName)) return;
    for (let c = node.firstChild; c; c = c.nextSibling) doNode(c);
  }
  const obs = new MutationObserver((list) => {
    for (const m of list) {
      if (m.type === "characterData") doNode(m.target);
      else if (m.type === "attributes") { const v = m.target.getAttribute(m.attributeName); if (v) { const n = tr(v); if (n !== v) m.target.setAttribute(m.attributeName, n); } }
      else m.addedNodes.forEach(doNode);
    }
  });
  function start() {
    doNode(document.body); document.title = tr(document.title);
    obs.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }
  if (document.body) start(); else document.addEventListener("DOMContentLoaded", start);
  // Dialoge und Zwischenablage
  const oc = window.confirm.bind(window), oa = window.alert.bind(window), op = window.prompt.bind(window);
  window.confirm = (m) => oc(trText(String(m))); window.alert = (m) => oa(trText(String(m))); window.prompt = (m, d) => op(trText(String(m)), d);
  if (navigator.clipboard && navigator.clipboard.writeText) {
    const ow = navigator.clipboard.writeText.bind(navigator.clipboard);
    navigator.clipboard.writeText = (t) => ow(trText(t));
  }
})();
