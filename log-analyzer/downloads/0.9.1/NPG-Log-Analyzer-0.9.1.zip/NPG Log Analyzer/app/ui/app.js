"use strict";
/* NPG Log Analyzer – Oberfläche */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const S = { settings: {}, res: { gw2: null, loa: null }, view: { gw2: "abend", loa: "abend" }, game: "gw2", histGame: "gw2", tab: "gw2", liveSig: null, liveTimer: null };

async function api(path, body) {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json", "X-NPG": "1" }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || r.statusText);
  return j;
}
async function job(path, body, statusEl) {
  const { job: id } = await api(path, body);
  return new Promise((res, rej) => {
    const tick = async () => {
      const j = await api("/api/job/" + id);
      if (statusEl) statusEl.innerHTML = j.state === "running" ? `<span class="spin"></span>${esc(j.msg)}` : "";
      if (j.state === "done") return res(j.result);
      if (j.state === "error") return rej(new Error(j.msg));
      setTimeout(tick, 400);
    };
    tick();
  });
}
function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("on"); clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove("on"), 2600); }
function setStatus(el, msg, err) { el.className = "status" + (err ? " err" : ""); el.innerHTML = msg ? esc(msg) : ""; }
async function copy(text) { try { await navigator.clipboard.writeText(text); } catch { const ta = document.createElement("textarea"); ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); } toast("In die Zwischenablage kopiert"); }
const isSup = (r) => r === "Heal" || r === "Tank";
const fmtK = (v) => v == null ? "–" : (v / 1000).toLocaleString(LOC, { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + "k";
function fmtBig(v) { if (v == null) return "–"; const a = Math.abs(v); const f = (x, u) => x.toLocaleString(LOC, { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + " " + u; if (a >= 1e12) return f(v / 1e12, UNITS.Bio); if (a >= 1e9) return f(v / 1e9, UNITS.Mrd); if (a >= 1e6) return f(v / 1e6, UNITS.Mio); if (a >= 1e3) return Math.round(v / 1e3) + "k"; return String(Math.round(v)); }
const fmtDur = (ms) => { if (ms == null) return "–"; const s = Math.round(ms / 1000); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };
function meter(p, ref, neutral) {
  if (p == null) return '<span class="cls">–</span>';
  const w = Math.max(0, Math.min(p, 150)) / 150 * 100;
  const col = neutral ? "#8c97ad" : p >= 90 ? "var(--ok)" : p >= 70 ? "var(--warn)" : "var(--bad)";
  return `<span class="meter"><i style="width:${w}%;background:${col}"></i><u></u></span><span class="pct">${ref ? esc(ref) + " / " : ""}${p} %</span>`;
}

/* ---------------- Tabs + Design-Wechsel ---------------- */
function syncNav() {
  $$("[data-game-sw]").forEach((b) => b.classList.toggle("on", b.dataset.gameSw === S.game));
  $$("[data-only]").forEach((e) => e.classList.toggle("hidden", e.dataset.only !== S.game));
}
function showTab(t) {
  if (t === "gw2" || t === "loa") S.game = t;
  if (t === "pl" || t === "boss" || t === "cmp" || t === "golem" || t === "live") S.game = "gw2";
  S.histGame = S.game; S.tab = t;
  document.body.dataset.game = S.game; syncNav();
  $$(".tab").forEach((b) => b.classList.toggle("active", b.dataset.tab === t));
  $$(".view").forEach((v) => v.classList.toggle("hidden", v.id !== "view-" + t));
  if (t === "pl") loadPlayers();
  if (t === "boss") { loadBosses(); renderWeek(); }
  if (t === "cmp") renderCmpPick();
  if (t === "hist") loadHistory();
  if (t === "set") renderSettings();
  if (t === "golem") loadGolem();
  if (t === "live" && !$("#live-frame").src) $("#live-frame").src = "/live?embed=1";
  window.scrollTo(0, 0);
}
/* Spiel-Umschalter oben in der Seitenleiste: Verlauf/Einstellungen bleiben offen, sonst zur Auswertung des Spiels */
$$("[data-game-sw]").forEach((b) => b.addEventListener("click", () => {
  const g = b.dataset.gameSw; if (g === S.game) return;
  S.game = g;
  showTab(S.tab === "hist" || S.tab === "set" ? S.tab : g);
}));
$$(".tab").forEach((b) => b.addEventListener("click", () => showTab(b.dataset.tab)));
const PAYPAL = "https://www.paypal.com/paypalme/nerdpublicgaming93";
$("#coffee").onclick = () => api("/api/open_url", { url: PAYPAL }).catch((e) => toast(e.message));
$$(".social [data-url]").forEach((b) => b.onclick = () => api("/api/open_url", { url: b.dataset.url }).catch((e) => toast(e.message)));
async function setLanguage(l) {
  if (l === window.NPG_LANG) return;
  await api("/api/settings", { language: l }); location.reload();
}
$$(".langsw [data-lang]").forEach((b) => { b.classList.toggle("on", b.dataset.lang === window.NPG_LANG); b.onclick = () => setLanguage(b.dataset.lang); });

/* ---------------- GW2 ---------------- */
async function gw2Scan() {
  const st = $("#gw2-status");
  try {
    const r = await job("/api/gw2/scan", {}, st);
    const sel = $("#gw2-day");
    sel.innerHTML = r.days.length ? r.days.map(([d, n]) => `<option value="${d}">${new Date(d + "T12:00").toLocaleDateString(LOC, { weekday: "short", day: "2-digit", month: "2-digit", year: "numeric" })} · ${n} Log${n > 1 ? "s" : ""}</option>`).join("") : "<option value=''>keine Logs gefunden</option>";
    setStatus(st, `${r.count} Logs gefunden` + (r.missing ? ` · ${r.missing} .zevtc ohne Elite-Insights-HTML (in EI parsen lassen, dann werden sie mitgezählt)` : ""));
    S.liveSig = (await api("/api/gw2/signature")).sig;
  } catch (e) { setStatus(st, e.message, true); }
}
async function gw2Analyze(links) {
  const st = $("#gw2-status");
  const day = $("#gw2-day").value;
  if (!links && !day) return setStatus(st, "Kein Abend ausgewählt.", true);
  try {
    const r = await job("/api/gw2/analyze", links ? { links } : { day }, st);
    S.res.gw2 = r; S.view.gw2 = "abend";
    setStatus(st, `Fertig · ${r.encs.length} Boss${r.encs.length > 1 ? "e" : ""} ausgewertet` + (r.prev_day ? ` · Vergleich mit ${new Date(r.prev_day + "T12:00").toLocaleDateString(LOC)}` : ""));
    renderResult("gw2");
  } catch (e) { setStatus(st, e.message, true); }
}
$("#gw2-go").onclick = () => gw2Analyze();
$("#gw2-rescan").onclick = gw2Scan;
$("#gw2-links-toggle").onclick = () => $("#gw2-links-box").classList.toggle("hidden");
$("#gw2-links-go").onclick = () => { const l = $("#gw2-links").value.split(/\s+/).filter((x) => x.includes("dps.report")); if (!l.length) return toast("Keine dps.report-Links erkannt"); gw2Analyze(l); };
$("#gw2-live").onchange = (e) => {
  clearInterval(S.liveTimer);
  if (!e.target.checked) return toast("Live-Modus aus");
  toast("Live-Modus an – neue Logs werden automatisch ausgewertet");
  S.liveTimer = setInterval(async () => {
    try {
      const { sig } = await api("/api/gw2/signature");
      if (S.liveSig && sig !== S.liveSig) { S.liveSig = sig; await gw2Scan(); $("#gw2-day").selectedIndex = 0; await gw2Analyze(); toast("Neuer Log ausgewertet"); }
      S.liveSig = sig;
    } catch {}
  }, Math.max(10, S.settings.live_interval || 20) * 1000);
};

/* ---------------- LOA ---------------- */
async function loaDays() {
  const st = $("#loa-status");
  try {
    const r = await job("/api/loa/days", {}, st);
    $("#loa-day").innerHTML = r.days.length ? r.days.map(([d, n]) => `<option value="${d}">${new Date(d + "T12:00").toLocaleDateString(LOC, { weekday: "short", day: "2-digit", month: "2-digit", year: "numeric" })} · ${n} Kampf${n > 1 ? "e" : ""}</option>`).join("") : "<option value=''>keine Kämpfe</option>";
    setStatus(st, "");
  } catch (e) { setStatus(st, e.message, true); }
}
async function loaAnalyze() {
  const st = $("#loa-status");
  try {
    const r = await job("/api/loa/analyze", { day: $("#loa-day").value }, st);
    S.res.loa = r; S.view.loa = "abend";
    setStatus(st, `Fertig · ${r.encs.length} Gate${r.encs.length > 1 ? "s" : ""} ausgewertet`);
    renderResult("loa");
  } catch (e) { setStatus(st, e.message, true); }
}
$("#loa-go").onclick = loaAnalyze;
$("#loa-rescan").onclick = loaDays;

/* ---------------- Ergebnis-Ansicht ---------------- */
const CAT_ORDER = ["raid", "strike", "fractal", "other"];
const CAT_LABEL = { raid: "Raids", strike: "Strikes", fractal: "Fraktale", other: "Sonstiges", golem: "Golem" };
S.cat = { gw2: "all" };
function encCats(list) { return CAT_ORDER.filter((c) => list.some((e) => (e.cat || "other") === c)); }
function visibleEncs(encs) { return S.cat.gw2 === "all" ? encs : encs.filter((e) => (e.cat || "other") === S.cat.gw2); }
function renderResult(game) {
  const r = S.res[game]; const s = r.summary; const box = $("#" + game + "-result");
  const g = s.goal || {};
  const prev = g.prev ? `<b>Ziel vom letzten Mal:</b> ${g.prev.text} – <span class="st-${g.prev.status}">${{ ok: "✔ erreicht", fail: "✘ verfehlt", partial: "~ teilweise", open: "○ offen" }[g.prev.status]}</span>${g.prev.detail ? " · " + esc(g.prev.detail) : ""}<br>` : "";
  const sv = S.settings;
  const subBtn = (e) => `<button class="subtab ${S.view[game] === e.key ? "on" : ""}" data-v="${esc(e.key)}"><span class="dot ${(e.kills || e.clears) ? "k" : "w"}"></span>${esc(e.title)}</button>`;
  let tabs, catBar = "";
  if (game === "gw2") {
    // Raids / Strikes / Fraktale: Boss-Reiter gruppiert, Filter nur wenn der Abend mehrere Arten hat
    const cats = encCats(r.encs);
    if (!cats.includes(S.cat.gw2)) S.cat.gw2 = "all";
    const shown = visibleEncs(r.encs);
    if (S.view.gw2 !== "abend" && !shown.some((e) => e.key === S.view.gw2)) S.view.gw2 = "abend";
    if (cats.length > 1) catBar = `<div class="seg catbar">${["all", ...cats].map((c) => `<button data-cat="${c}" class="${S.cat.gw2 === c ? "on" : ""}">${c === "all" ? "Alle" : CAT_LABEL[c]} <small>${c === "all" ? r.encs.length : r.encs.filter((e) => (e.cat || "other") === c).length}</small></button>`).join("")}</div>`;
    tabs = `<button class="subtab ${S.view.gw2 === "abend" ? "on" : ""}" data-v="abend">${S.cat.gw2 === "all" ? "Ganzer Abend" : "Übersicht " + CAT_LABEL[S.cat.gw2]}</button>`
      + cats.filter((c) => S.cat.gw2 === "all" || S.cat.gw2 === c).map((c) => (cats.length > 1 && S.cat.gw2 === "all" ? `<span class="subgrp">${CAT_LABEL[c]}</span>` : "")
        + shown.filter((e) => (e.cat || "other") === c).sort((a, b) => (a.order || 0) - (b.order || 0) || a.start.localeCompare(b.start)).map(subBtn).join("")).join("");
  } else {
    tabs = [`<button class="subtab ${S.view[game] === "abend" ? "on" : ""}" data-v="abend">Ganzer Abend</button>`].concat(r.encs.map(subBtn)).join("");
  }
  box.innerHTML = `
    <div class="hero"><div class="kicker">${esc(s.content)} · ${esc(s.date)}</div><h1>${esc(s.title)}</h1><div class="sub">${esc(s.subtitle)}</div></div>
    <div class="kpis">${s.kpis.map((k) => `<div class="kpi ${k.tone || ""}"><div class="l">${esc(k.label)}</div><div class="v">${esc(k.value)}</div><div class="n">${esc(k.note || "")}</div></div>`).join("")}</div>
    <div class="actions">
      <button class="btn" data-pdf="einseiter">PDF Einseiter</button>
      <button class="btn" data-pdf="ausfuehrlich">PDF ausführlich</button>
      <button class="btn" data-pdf="beide">Beide PDFs</button>
      <button class="btn ghost" id="${game}-folder">PDF-Ordner öffnen</button>
      ${game === "gw2" ? `<button class="btn ghost" id="gw2-csv" title="Spieler pro Boss und alle Versuche als CSV (öffnet in Excel)">CSV-Export</button>` : ""}
      <span class="sep"></span>
      <button class="btn" id="${game}-copy-dc">Discord-Text kopieren</button>
      ${sv.discord_enabled && sv.discord_webhook ? `<button class="btn" id="${game}-send-dc">An Discord senden</button>` : ""}
      <span class="sep"></span>
      <button class="btn" id="${game}-copy-ai" title="Kompakte Zusammenfassung für eine KI (z. B. hier im Claude-Chat einfügen)">KI-Zusammenfassung kopieren</button>
      ${sv.ai_enabled && sv.ai_key ? `<button class="btn" id="${game}-ask-ai">KI fragen</button>` : ""}
      ${game === "gw2" ? `<span class="sep"></span><button class="btn" id="gw2-upload" title="Nur auf Klick: lädt die .zevtc der Versuche zu dps.report hoch">Logs zu dps.report hochladen</button>` : ""}
      <span class="muted" id="${game}-pdf-status"></span>
    </div>
    <div class="grid2">
      <div class="card"><h3>Top 3 fürs nächste Mal</h3><ol>${s.top3.map((t) => `<li>${t}</li>`).join("")}</ol>
        <div class="goal">${prev}<b>Ziel fürs nächste Mal:</b> ${g.next ? g.next.text : "–"}</div></div>
      <div class="card"><h3>MVP &amp; Ehrenpreis</h3><p style="margin:0 0 8px"><b>MVP:</b> ${s.mvp}</p><p style="margin:0"><b>Ehrenpreis:</b> ${s.honor}</p></div>
    </div>
    <div id="${game}-ai-out"></div>
    ${(s.badges_today || []).length ? `<div class="card"><h3>Heute verdient</h3><div class="badges">${s.badges_today.slice(0, 8).map((b) => badgeHtml(b, b.who)).join("")}</div>
      ${s.badges_today.length > 8 ? `<details style="margin-top:10px"><summary class="muted" style="cursor:pointer">Alle ${s.badges_today.length} Abzeichen anzeigen</summary><div class="badges" style="margin-top:10px">${s.badges_today.slice(8).map((b) => badgeHtml(b, b.who)).join("")}</div></details>` : ""}</div>` : ""}
    ${catBar}<div class="subtabs">${tabs}</div>
    <div id="${game}-detail"></div>`;
  $$(".subtab", box).forEach((b) => b.onclick = () => { S.view[game] = b.dataset.v; $$(".subtab", box).forEach((x) => x.classList.toggle("on", x === b)); renderDetail(game); });
  $$("[data-cat]", box).forEach((b) => b.onclick = () => { S.cat.gw2 = b.dataset.cat; const y = window.scrollY; renderResult(game); window.scrollTo(0, y); });
  $$("[data-pdf]", box).forEach((b) => b.onclick = () => makePdf(game, b.dataset.pdf));
  $(`#${game}-folder`).onclick = () => api("/api/open_folder", {});
  $(`#${game}-copy-dc`).onclick = () => copy(s.discord);
  const sd = $(`#${game}-send-dc`); if (sd) sd.onclick = async () => { if (!confirm("Zusammenfassung jetzt an den Discord-Kanal senden?")) return; try { await api("/api/discord", { text: s.discord }); toast("An Discord gesendet"); } catch (e) { toast(e.message); } };
  $(`#${game}-copy-ai`).onclick = async () => { const d = await api("/api/digest?game=" + game); copy("Bitte werte diesen Abend aus (Einschätzung, 3 Tipps, Discord-Text):\n\n" + d.text); };
  const aa = $(`#${game}-ask-ai`); if (aa) aa.onclick = async () => {
    const out = $(`#${game}-ai-out`); out.innerHTML = `<div class="card"><h3>KI-Einschätzung</h3><div class="status"><span class="spin"></span>Frage die KI …</div></div>`;
    try { const r2 = await job("/api/ai", { game }, null); out.innerHTML = `<div class="card"><h3>KI-Einschätzung</h3><div class="ai-box">${esc(r2.text)}</div><div class="actions" style="margin:10px 0 0"><button class="btn small" id="${game}-ai-copy">Text kopieren</button></div></div>`; $(`#${game}-ai-copy`).onclick = () => copy(r2.text); }
    catch (e) { out.innerHTML = `<div class="card"><h3>KI-Einschätzung</h3><div class="status err">${esc(e.message)}</div></div>`; }
  };
  if (game === "gw2") {
    $("#gw2-csv").onclick = () => doExport("abend");
    $("#gw2-upload").onclick = () => uploadLogs(null);
  }
  renderDetail(game);
}

async function makePdf(game, kind) {
  const scope = S.view[game] === "abend" ? null : S.view[game];
  const st = $(`#${game}-pdf-status`);
  try { const r = await job("/api/pdf", { game, scope, kind }, st); st.textContent = "Gespeichert: " + r.files.map((f) => f.split(/[\\/]/).pop()).join(" · "); }
  catch (e) { st.innerHTML = `<span class="bad">${esc(e.message)}</span>`; }
}

function renderDetail(game) {
  const r = S.res[game]; const s = r.summary; const v = S.view[game]; const el = $(`#${game}-detail`);
  if (v === "abend") el.innerHTML = game === "gw2" ? gw2Evening(s, r) : loaEvening(s, r);
  else { const e = r.encs.find((x) => x.key === v); el.innerHTML = game === "gw2" ? gw2Boss(e) : loaGate(e); }
  const cp = $("#copy-dc-inline", el); if (cp) cp.onclick = () => copy(s.discord);
  $$("[data-open]", el).forEach((b) => b.onclick = () => api("/api/open_url", { url: b.dataset.open }).catch((e) => toast(e.message)));
  const rp = $("#ref-parse", el); if (rp) rp.onclick = () => parseRefs(r.encs.find((x) => x.key === v));
  $$("[data-cmp]", el).forEach((b) => b.onclick = (ev) => { ev.preventDefault(); openCompare({ day: S.res.gw2.summary.day_key, id: b.dataset.cmp }, { day: S.res.gw2.summary.day_key, id: b.dataset.cmpRef }); });
  $$("[data-upload]", el).forEach((b) => b.onclick = () => uploadLogs(b.dataset.upload));
  $$("[data-rot]", el).forEach((b) => b.onclick = (ev) => { ev.preventDefault(); showRotation(r.encs.find((x) => x.key === v), b.dataset.rot, b); });
}

function compareCard(s) {
  if (!s.compare || !s.compare.length) return `<div class="card"><h3>Vergleich mit dem letzten Abend</h3><p class="muted" style="margin:0">Noch kein früherer Abend im Verlauf – ab dem nächsten Mal steht hier, was besser oder schlechter geworden ist.</p></div>`;
  return `<div class="card"><h3>Vergleich mit dem letzten Abend</h3><table><tr><th></th><th class="num">Heute</th><th class="num">Letztes Mal</th><th class="num">Differenz</th></tr>
    ${s.compare.map((c) => `<tr><td>${esc(c.what)}</td><td class="num">${esc(c.now)}</td><td class="num">${esc(c.before)}</td><td class="num ${c.tone}">${esc(c.diff)}</td></tr>`).join("")}</table></div>`;
}
function bestsShame(s) {
  return `<div class="grid2b"><div class="card"><h3>Persönliche Bestwerte</h3><ul>${s.bests.map((x) => `<li>${x}</li>`).join("")}</ul></div>
    <div class="card"><h3>Wall of Shame</h3><ul>${s.shame.map((x) => `<li>${x}</li>`).join("")}</ul></div></div>`;
}
function discordCard(s) {
  return `<div class="card"><h3>Discord-Kurzfassung</h3><pre class="discord">${esc(s.discord)}</pre><div class="actions" style="margin:10px 0 0"><button class="btn small" id="copy-dc-inline">Kopieren</button></div></div>`;
}
function attemptsTable(atts, withBoss, cmpRef) {
  return `<table><tr><th>Zeit</th>${withBoss ? "<th>Boss</th>" : ""}<th>Ergebnis</th><th class="num">Dauer</th><th>Erreicht</th><th>Erster Tod</th><th>Ursache</th><th></th></tr>
    ${atts.map((a) => `<tr><td>${esc(a.time)}</td>${withBoss ? `<td>${esc(a.boss)}</td>` : ""}<td><span class="badge b-${a.result}">${esc(a.result)}</span></td><td class="num">${esc(a.dur)}</td><td>${esc(a.reached)}</td><td>${esc(a.first_death)}</td><td>${esc(a.cause)}</td><td>${a.url ? `<a href="${esc(a.url)}" target="_blank" style="color:var(--accent)">Log</a>` : '<span class="cls">lokal</span>'}${cmpRef && a.id && cmpRef.id !== a.id && a.result !== "Reset" ? ` · <a href="#" data-cmp="${esc(a.id)}" data-cmp-ref="${esc(cmpRef.id)}" style="color:var(--accent)" title="Mit ${esc(cmpRef.label)} vergleichen">vergleichen</a>` : ""}</td></tr>`).join("")}</table>`;
}
function progTable(pg, fmt) {
  if (!pg || pg.cols.length < 2) return "";
  return `<div class="card scroll"><h3>Entwicklung über die Versuche</h3><table class="prog"><tr><th>Spieler</th>${pg.cols.map((c) => `<th>${esc(c)}</th>`).join("")}<th>Trend</th><th>Beständigkeit</th></tr>
    ${pg.rows.map((r) => `<tr><td><b>${esc(r.name)}</b> <span class="cls">${esc(r.cls)}</span></td>${r.cells.map((c) => c ? `<td class="${c.best ? "best" : c.worst ? "worst" : ""}">${esc(c.v)}${c.dead ? '<span class="dead"> †</span>' : ""}</td>` : '<td class="cls">–</td>').join("")}<td class="${r.tone}">${esc(r.trend)}</td><td class="cls">${r.cv != null ? `${esc(r.steady)} (±${r.cv} %)` : "–"}</td></tr>`).join("")}</table>
    <div class="legend">grün = bester, rot = schwächster Versuch des Spielers · † = gestorben · Trend = letzter gegen ersten eigenen Versuch · Beständigkeit = Schwankung der DPS über die Versuche (ohne Versuche mit Tod)</div></div>`;
}

/* GW2: Abend */
function catPlayerRows(s, encs) {
  // Spieler nur über die Bosse der gewählten Art (Ø nach Kampfdauer gewichtet, wie beim ganzen Abend)
  const tot = encs.reduce((n, e) => n + e.players.reduce((m, p) => m + p.boss_dmg, 0), 0) || 1;
  return s.players.map((p) => {
    let w = 0, sum = 0, dmg = 0, deaths = 0, n = 0;
    encs.forEach((e) => { const ep = e.players.find((x) => x.acc === p.acc); if (!ep) return; n++; dmg += ep.boss_dmg; deaths += ep.deaths_n;
      if (ep.pct_med != null) { sum += ep.pct_med * e.target_dur; w += e.target_dur; } });
    return n ? { ...p, pct_med: w ? Math.round(sum / w) : null, dmg, share: Math.round(dmg / tot * 100), deaths, bosses: n } : null;
  }).filter(Boolean).sort((a, b) => b.dmg - a.dmg);
}
function gw2Evening(s, r) {
  if (S.cat.gw2 !== "all") {
    const encs = visibleEncs(r.encs); const lab = CAT_LABEL[S.cat.gw2];
    const prow = catPlayerRows(s, encs).map((p) => `<tr><td><b>${esc(p.name)}</b><br><span class="cls">${esc(p.prof)}${p.role !== "DPS" ? " · " + esc(p.role) : ""} · ${esc(p.acc)}</span></td>
      <td class="num">${fmtBig(p.dmg)} · <b>${p.share} %</b></td><td>${isSup(p.role) ? `<span class="cls">– (${p.role})</span>` : meter(p.pct_med)}</td><td class="num">${p.deaths || "–"}</td><td class="num">${p.bosses}</td></tr>`).join("");
    const brow = encs.map((e) => `<tr><td><b>${esc(e.title)}</b>${e.group ? `<br><span class="cls">${esc(e.group)}</span>` : ""}</td><td class="num">${e.n_attempts}</td><td><span class="badge b-${e.kills ? "Kill" : "Wipe"}">${e.kills ? "Kill" : "kein Kill"}</span></td>
      <td class="num">${fmtDur(e.best_kill_ms)}</td><td class="num">${fmtDur(e.wm_med_ms)}</td><td class="num ${e.best_kill_ms && e.wm_med_ms ? (e.best_kill_ms <= e.wm_med_ms ? "good" : "bad") : ""}">${e.best_kill_ms && e.wm_med_ms ? ((e.best_kill_ms - e.wm_med_ms) > 0 ? "+" : "−") + Math.abs(Math.round((e.best_kill_ms - e.wm_med_ms) / 1000)) + " s" : "–"}</td><td class="num">${e.deaths_total}</td></tr>`).join("");
    return `<div class="card"><h3>${lab} an diesem Abend</h3><table><tr><th>Boss</th><th class="num">Versuche</th><th>Ergebnis</th><th class="num">Kill-Zeit</th><th class="num">Wingman-Median</th><th class="num">Differenz</th><th class="num">Tode</th></tr>${brow}</table></div>
      <div class="card scroll"><h3>Spieler · nur ${lab}</h3><table><tr><th>Spieler</th><th class="num">Boss-Schaden · Anteil</th><th>Ø vs. Klassen-Median</th><th class="num">Tode</th><th class="num">Bosse</th></tr>${prow}</table>
      <div class="legend">Nur die ${lab} dieses Abends, Ø nach Kampfdauer gewichtet. Noten, Top 3, Ziele, PDFs und Discord-Text gelten weiter für den ganzen Abend – oben „Alle“ wählen für die komplette Übersicht.</div></div>`;
  }
  const rows = s.players.map((p) => `<tr><td><b>${esc(p.name)}</b><br><span class="cls">${esc(p.prof)}${p.role !== "DPS" ? " · " + esc(p.role) : ""} · ${esc(p.acc)}</span></td>
    <td><span class="badge b-${p.grade}">${p.grade}</span></td><td class="num">${fmtBig(p.dmg)} · <b>${p.share} %</b></td>
    <td>${isSup(p.role) ? `<span class="cls">– (${p.role})</span>` : meter(p.pct_med)}</td><td class="num">${p.deaths || "–"}</td><td class="num">${p.bosses}</td><td>${esc(p.sentence)}</td></tr>`).join("");
  const bosses = visibleEncs(r.encs).map((e) => `<tr><td><b>${esc(e.title)}</b></td><td class="num">${e.n_attempts}</td><td><span class="badge b-${e.kills ? "Kill" : "Wipe"}">${e.kills ? "Kill" : "kein Kill"}</span></td>
    <td class="num">${fmtDur(e.best_kill_ms)}</td><td class="num">${fmtDur(e.wm_med_ms)}</td><td class="num ${e.best_kill_ms && e.wm_med_ms ? (e.best_kill_ms <= e.wm_med_ms ? "good" : "bad") : ""}">${e.best_kill_ms && e.wm_med_ms ? ((e.best_kill_ms - e.wm_med_ms) > 0 ? "+" : "−") + Math.abs(Math.round((e.best_kill_ms - e.wm_med_ms) / 1000)) + " s" : "–"}</td><td class="num">${e.deaths_total}</td></tr>`).join("");
  return `
    <div class="card"><h3>Bosse des Abends</h3><table><tr><th>Boss</th><th class="num">Versuche</th><th>Ergebnis</th><th class="num">Kill-Zeit</th><th class="num">Wingman-Median</th><th class="num">Differenz</th><th class="num">Tode</th></tr>${bosses}</table>
      <div class="legend">Vergleichswerte: GW2 Wingman, Patch ${esc(s.patch)}${s.wm_updated ? ", Stand " + esc(s.wm_updated) : ""}. Klick oben auf einen Boss für alle Details.</div></div>
    <div class="card scroll"><h3>Spieler über den Abend</h3><table><tr><th>Spieler</th><th>Note</th><th class="num">Boss-Schaden · Anteil</th><th>Ø vs. Klassen-Median</th><th class="num">Tode</th><th class="num">Bosse</th><th>Kurz</th></tr>${rows}</table>
      ${s.excluded && s.excluded.length ? `<div class="legend"><b>Nicht gewertet:</b> ${s.excluded.map(esc).join(" · ")}</div>` : ""}
      <div class="legend">Ø % vom Wingman-Klassen-Median über alle Kills, nach Kampfdauer gewichtet (Strich = 100 %) · Note: Top ab Median ohne große Fehler · Okay ein Punkt · Baustelle deutlich unter Median oder mehrere Fehler</div></div>
    <div class="grid2b"><div class="card"><h3>Was gebremst hat</h3><ul>${s.issues.map((x) => `<li>${x}</li>`).join("")}</ul></div>${compareCard(s)}</div>
    ${goalsCard(s)}
    ${bestsShame(s)}
    <div class="card scroll"><h3>Alle Versuche</h3>${attemptsTable(s.attempts, true)}</div>
    ${discordCard(s)}`;
}

/* Begriffe wie in Elite Insights / dps.report */
const T = { up: "Uptime", gg: "Generation (Group)", gs: "Generation (Squad)", bb: "Breakbar Damage", tw: "Time wasted", st: "Ø Stacks" };
function playerNotes(p) {
  const n = p.deaths.map((d) => `Tod ${fmtDur(d.t)} (${esc(d.cause)})`);
  n.push(p.food ? `Food: ${esc((p.food_names || []).join(", ") || "ja")}` : '<span class="bad">kein Food</span>');
  n.push(p.util ? `Utility: ${esc((p.util_names || []).join(", ") || "ja")}` : '<span class="bad">kein Utility</span>');
  if (p.wasted_s > 5) n.push(`${T.tw} ${p.wasted_s.toFixed(1).replace(".", DEC)} s`);
  if (p.cc) n.push(`${T.bb} ${p.cc.toLocaleString(LOC)}`);
  (p.boons || []).forEach((b) => { if (!b.stacking && b.gen_group >= 10 && (b.name === "Quickness" || b.name === "Alacrity")) n.push(`${esc(b.name)} ${T.gg} ${Math.round(b.gen_group)} %`); });
  const q = (p.boons || []).find((b) => b.name === "Quickness"); if (q) n.push(`Quickness ${T.up} ${Math.round(q.uptime)} %`);
  return n.join(", ");
}
function boonCell(b) {
  if (b.stacking) return `<td class="num ${b.name === "Might" ? (b.stacks >= 20 ? "good" : "bad") : ""}">${String(b.stacks).replace(".", DEC)}</td>`;
  const goal = ["Quickness", "Alacrity", "Fury"].includes(b.name) ? 90 : null;
  return `<td class="num ${goal ? (b.uptime >= goal ? "good" : "bad") : ""}">${b.uptime} %</td>`;
}

/* GW2: einzelner Boss */
function gw2Boss(e) {
  const diff = e.best_kill_ms && e.wm_med_ms ? e.best_kill_ms - e.wm_med_ms : null;
  const k = [
    { l: "Kill-Zeit", v: fmtDur(e.best_kill_ms), n: e.kills ? `${e.kills} Kill${e.kills > 1 ? "s" : ""}` : "kein Kill" },
    { l: "Wingman-Median", v: fmtDur(e.wm_med_ms), n: e.wm_top_ms ? "Bestzeit " + fmtDur(e.wm_top_ms) : (e.wm_ok ? "" : "nicht erreichbar") },
    { l: "Differenz", v: diff == null ? "–" : (diff > 0 ? "+" : "−") + Math.abs(Math.round(diff / 1000)) + " s", n: "zum Median", t: diff == null ? "" : diff <= 0 ? "good" : "bad" },
    { l: "Versuche", v: String(e.n_attempts), n: `${e.deaths_total} Tode` + (e.n_resets ? ` · ${e.n_resets} Reset` : "") },
  ];
  const rows = e.players.map((p) => `<tr><td><b>${esc(p.name)}</b><br><span class="cls">${esc(p.prof)}${p.role !== "DPS" ? " · " + esc(p.role) : ""} · Gr. ${p.group}</span></td>
    <td><span class="badge b-${p.grade}">${p.grade}</span></td><td class="num">${fmtK(p.boss_dps)}</td><td class="num">${fmtBig(p.boss_dmg)} · <b>${p.share} %</b><br><span class="cls">alle Ziele ${fmtBig(p.all_dmg)}</span></td>
    <td>${isSup(p.role) ? `<span class="cls">– (${p.role})</span>` : p.excluded ? `<span class="cls" title="${esc(p.excluded)}">nicht gewertet (${p.pct_raw} %)<br>${esc(p.excluded)}</span>` : meter(p.pct_med, p.med ? fmtK(p.med) : null)}</td><td>${isSup(p.role) ? "" : meter(p.pct_top, p.top ? fmtK(p.top) : null, true)}</td>
    <td class="num">${p.deaths_n ? `<span class="dead">${p.deaths_n}</span>` : "–"} / ${p.downs || "–"}</td>
    <td class="cls">${playerNotes(p)}${!isSup(p.role) && e.target_id ? `<br><a href="#" data-rot="${esc(p.acc)}" style="color:var(--accent)">Rotation gegen Top-Log</a>` : ""}</td></tr>`).join("");
  const bcols = (e.boons[0]?.all || []);
  const boons = e.boons.map((b) => `<tr><td><b>${esc(b.group)}</b><br><span class="cls">${esc(b.members)}</span></td>${(b.all || []).map(boonCell).join("")}</tr>`).join("");
  const gset = new Set(e.boon_givers.flatMap((g) => g.gives.map((x) => x.name)));
  const gcols = bcols.map((b) => b.name).filter((n) => gset.has(n));
  const givers = e.boon_givers.map((g) => `<tr><td><b>${esc(g.name)}</b><br><span class="cls">${esc(g.prof)} · Gr. ${g.group}</span></td>${gcols.map((c) => { const x = g.gives.find((y) => y.name === c); return `<td class="num">${x ? (x.stacking ? String(x.gen_group).replace(".", DEC) : Math.round(x.gen_group) + " %") : '<span class="cls">–</span>'}</td>`; }).join("")}</tr>`).join("");
  const ph = e.phases.map((p) => `<tr><td>${esc(p.name)}</td><td class="num">${p.ours}</td><td class="num">${p.med}</td><td class="num ${p.tone || ""}">${p.diff}</td></tr>`).join("");
  const mech = e.mechanics.map((m) => `<tr><td>${esc(m.name)}</td><td class="num">${m.hits}</td><td>${esc(m.top[0])} (${m.top[1]}×)</td></tr>`).join("");
  return `
    <div class="kpis">${k.map((x) => `<div class="kpi ${x.t || ""}"><div class="l">${x.l}</div><div class="v">${x.v}</div><div class="n">${esc(x.n)}</div></div>`).join("")}</div>
    <div class="card scroll"><h3>Spieler im ${e.target_is_kill ? "Kill" : "besten Versuch"} (${e.target_time})</h3><table><tr><th>Spieler</th><th>Note</th><th class="num">Boss-DPS</th><th class="num">Schaden · Anteil</th><th>vs. Klassen-Median</th><th>Potenzial (Top-Log)</th><th class="num">Tode / Downs</th><th>Anmerkung</th></tr>${rows}</table>
      <div class="legend">„Wert / %“ = Wingman-Referenz der Klasse und unser Anteil · graue Leiste = bester Wingman-Log der Klasse (Speedrun-Niveau, nur als Ansporn) · „nicht gewertet“ = Klassen-Median bei Wingman offensichtlich verzerrt${e.wm_updated ? " · Wingman-Stand " + esc(e.wm_updated) : ""}</div></div>
    <div id="rot-out"></div>
    ${costsCard(e)}
    <div class="card scroll"><h3>Alle Versuche</h3>${attemptsTable(e.attempts, false, cmpRefOf(e))}
      <div class="actions" style="margin:10px 0 0">${S.res.gw2 && !S.res.gw2.links ? `<button class="btn small" data-upload="${esc(e.key)}">Diesen Boss zu dps.report hochladen</button>` : ""}<span class="legend" style="margin:0">„vergleichen“ öffnet den Versuch neben dem besten Kill im Vergleich-Tab.</span></div></div>
    ${timelineCard(e)}
    ${progTable(e.progress)}
    ${phaseDpsCard(e)}
    <div class="card scroll"><h3>Boon-${T.up} pro Gruppe</h3><table><tr><th>Gruppe</th>${bcols.map((b) => `<th class="num">${esc(b.name)}${b.stacking ? `<br><span class="cls">${T.st}</span>` : ""}</th>`).join("")}</tr>${boons}</table>
      <div class="legend">${T.up} im Schnitt der Untergruppe · Quickness, Alacrity, Fury grün ab 90 % · Might grün ab 20 Stacks · Might und Stability als ${T.st}</div></div>
    ${givers ? `<div class="card scroll"><h3>Boon-${T.gg}</h3><table><tr><th>Spieler</th>${gcols.map((c) => `<th class="num">${esc(c)}</th>`).join("")}</tr>${givers}</table>
      <div class="legend">Wie viel der Spieler seiner Untergruppe gibt (ohne sich selbst), wie in Elite Insights / dps.report · bei Might und Stability in Stacks · nur Werte ab 10 % (Might/Stability ab 3 Stacks)</div></div>` : ""}
    <div class="grid2b">
      <div class="card"><h3>Phasen vs. Wingman-Median</h3>${ph ? `<table><tr><th>Phase</th><th class="num">Wir</th><th class="num">Median</th><th class="num">Differenz</th></tr>${ph}</table>` : '<p class="muted" style="margin:0">Keine Phasen-Vergleichswerte für diesen Boss.</p>'}</div>
    <div class="card"><h3>Mechanik-Treffer (alle Versuche)</h3>${mech ? `<table><tr><th>Mechanik</th><th class="num">Treffer</th><th>Am meisten</th></tr>${mech}</table>` : '<p class="muted" style="margin:0">Keine nennenswerten Treffer.</p>'}</div>
    </div>
    ${boonPhaseCard(e)}
    ${positionCard(e)}
    <div class="grid2b">${breakbarCard(e) || "<div></div>"}${sourcesCard(e)}</div>`;
}

/* LOA: Abend */
function loaEvening(s, r) {
  const ref = s.has_ref;
  const rows = s.players.map((p) => `<tr><td><b>${esc(p.name)}</b><br><span class="cls">${esc(p.cls)} · ${esc(p.spec)}</span></td><td><span class="badge b-${p.grade}">${p.grade}</span></td>
    <td class="num">${fmtBig(p.dps_avg)}</td><td class="num">${fmtBig(p.dmg)}${p.support ? "" : ` · <b>${p.share} %</b>`}</td>
    <td>${p.support ? `<span class="cls">AP ${p.ap} % · Brand ${p.brand} % · Identity ${p.identity} %</span>` : meter(ref ? p.pct_med : p.pct_grp)}</td><td class="num">${p.deaths || "–"}</td><td>${esc(p.sentence)}</td></tr>`).join("");
  const gates = r.encs.map((g) => `<tr><td><b>${esc(g.title)}</b></td><td class="num">${g.n_attempts}</td><td><span class="badge b-${g.clears ? "Clear" : "Wipe"}">${g.clears ? "Clear" : "kein Clear"}</span></td><td class="num">${fmtDur(g.best_ms)}</td><td class="num">${g.deaths_total}</td></tr>`).join("");
  return `
    <div class="card"><h3>Gates des Tages</h3><table><tr><th>Gate</th><th class="num">Versuche</th><th>Ergebnis</th><th class="num">Clear-Zeit</th><th class="num">Tode</th></tr>${gates}</table></div>
    <div class="card scroll"><h3>Spieler über den Tag</h3><table><tr><th>Spieler</th><th>Note</th><th class="num">Ø DPS</th><th class="num">Schaden · Anteil</th><th>${ref ? "vs. Referenz" : "vs. Gruppen-Ø"}</th><th class="num">Tode</th><th>Kurz</th></tr>${rows}</table>
      <div class="legend">${ref ? "Prozent = DPS gegen deine Referenzwerte aus den Einstellungen." : "Keine Referenzwerte hinterlegt – Prozent = DPS im Vergleich zum Schnitt der DPS-Spieler. Referenzwerte (z. B. von lostark.bible) kannst du in den Einstellungen eintragen."}</div></div>
    <div class="grid2b"><div class="card"><h3>Was gebremst hat</h3><ul>${s.issues.map((x) => `<li>${x}</li>`).join("")}</ul></div>${compareCard(s)}</div>
    ${bestsShame(s)}
    <div class="card scroll"><h3>Alle Versuche</h3>${attemptsTable(s.attempts, true)}</div>
    ${discordCard(s)}`;
}

/* LOA: einzelnes Gate */
function loaGate(g) {
  const ref = g.has_ref;
  const k = [
    { l: "Clear-Zeit", v: fmtDur(g.best_ms), n: g.clears ? `${g.clears} Clear` : "kein Clear" },
    { l: "Versuche", v: String(g.n_attempts), n: g.difficulty },
    { l: "Tode", v: String(g.deaths_total), n: "alle Versuche", t: g.deaths_total > 4 ? "bad" : "" },
    { l: "Referenz", v: ref ? fmtBig(g.ref.dps) : "–", n: ref ? "DPS (Einstellungen)" : "keine hinterlegt" },
  ];
  const rows = g.players.map((p) => `<tr><td><b>${esc(p.name)}</b><br><span class="cls">${esc(p.cls)} · ${esc(p.spec)} · Party ${p.party}</span></td><td><span class="badge b-${p.grade}">${p.grade}</span></td>
    <td class="num">${fmtBig(p.dps)}</td><td class="num">${fmtBig(p.dmg)}${p.support ? "" : ` · <b>${p.share} %</b>`}</td>
    <td>${p.support ? `<span class="cls">AP ${Math.round(p.ap)} % · Brand ${Math.round(p.brand)} % · Identity ${Math.round(p.identity)} % · Hyper ${Math.round(p.hyper)} %</span>` : meter(ref ? p.pct_med : p.pct_grp, ref ? fmtBig(p.med) : null)}</td>
    <td class="num">${p.deaths_n ? `<span class="dead">${p.deaths_n}</span>` : "–"}</td><td class="cls">${p.deaths.map((d) => "Tod " + fmtDur(d.t)).join(", ")}</td></tr>`).join("");
  const parties = g.parties.map((p) => `<tr><td><b>${esc(p.group)}</b><br><span class="cls">${esc(p.members)}</span></td><td class="num ${p.ap >= 90 ? "good" : "bad"}">${p.ap} %</td><td class="num ${p.brand >= 85 ? "good" : "bad"}">${p.brand} %</td><td class="num ${p.identity >= 60 ? "good" : "bad"}">${p.identity} %</td><td class="num">${p.hyper} %</td></tr>`).join("");
  return `
    <div class="kpis">${k.map((x) => `<div class="kpi ${x.t || ""}"><div class="l">${x.l}</div><div class="v">${x.v}</div><div class="n">${esc(x.n)}</div></div>`).join("")}</div>
    <div class="card scroll"><h3>Spieler im ${g.target_is_kill ? "Clear" : "besten Versuch"} (${g.target_time})</h3><table><tr><th>Spieler</th><th>Note</th><th class="num">DPS</th><th class="num">Schaden · Anteil</th><th>${ref ? "vs. Referenz" : "vs. Gruppen-Ø"}</th><th class="num">Tode</th><th>Anmerkung</th></tr>${rows}</table></div>
    <div class="card scroll"><h3>Alle Versuche</h3>${attemptsTable(g.attempts, false)}</div>
    ${progTable(g.progress)}
    <div class="card"><h3>Klassen-Median von lostark.bible</h3>
      <p style="margin:0 0 8px">${ref ? `Hinterlegt${g.ref_saved ? " am " + esc(g.ref_saved) : ""} – die Prozente oben sind gegen den Median der jeweiligen Klasse gerechnet.` : "Noch keine Werte hinterlegt – oben wird mit dem Gruppenschnitt verglichen."}</p>
      <ol style="margin:0 0 10px"><li>Seite öffnen: <button class="btn small" data-open="https://lostark.bible/stats/raids">lostark.bible → Raid Performance öffnen</button></li>
        <li>Dort einstellen: <span class="muted">${g.hint.map(esc).join(" · ")}</span></li>
        <li>Die Tabelle markieren (am einfachsten Strg+A), kopieren (Strg+C) und hier einfügen:</li></ol>
      <textarea id="ref-text" rows="5" placeholder="Hier den kopierten Text von lostark.bible einfügen"></textarea>
      <div class="actions" style="margin:10px 0 0"><button class="btn" id="ref-parse">Einlesen</button><span class="muted" id="ref-msg"></span></div>
      <div id="ref-preview"></div></div>
    <div class="card"><h3>Supports pro Party</h3><table><tr><th>Party</th><th class="num">AP</th><th class="num">Brand</th><th class="num">Identity</th><th class="num">Hyper</th></tr>${parties}</table><div class="legend">Party-Uptime · Ziel: AP 90 %, Brand 85 %, Identity 60 %</div></div>`;
}

async function parseRefs(g) {
  const text = $("#ref-text").value; const msg = $("#ref-msg"); const box = $("#ref-preview");
  if (!text.trim()) return toast("Erst den Text von lostark.bible einfügen");
  const r = await api("/api/loa/parse_refs", { text });
  if (!r.rows.length) { msg.innerHTML = '<span class="bad">Keine Werte erkannt. Schick mir den eingefügten Text, dann passe ich das Einlesen an.</span>'; box.innerHTML = ""; return; }
  const mine = new Set(g.players.flatMap((p) => [p.cls.toLowerCase(), (p.spec || "").toLowerCase()]));
  msg.textContent = `${r.rows.length} Zeilen erkannt · Median-Spalte: ${r.columns.indexOf("median") + 1}. Wert`;
  box.innerHTML = `<table style="margin-top:10px"><tr><th>Klasse / Spec</th><th class="num">Median</th><th>Spieler heute</th></tr>
    ${r.rows.map((x) => `<tr><td>${esc(x.label)}</td><td class="num">${fmtBig(x.median)}</td><td>${[...mine].some((m) => m && x.label.toLowerCase().includes(m)) ? '<span class="good">✔</span>' : ""}</td></tr>`).join("")}</table>
    <div class="actions" style="margin:10px 0 0"><button class="btn primary" id="ref-save">Für ${esc(g.title)} speichern</button><span class="muted">Gesamt-Median: ${fmtBig(r.overall)}</span></div>`;
  $("#ref-save").onclick = async () => { await api("/api/loa/save_refs", { key: g.key, rows: r.rows, overall: r.overall }); S.settings = await api("/api/settings"); toast("Gespeichert – werte neu aus …"); await loaAnalyze(); S.view.loa = g.key; renderResult("loa"); };
}

/* ---------------- Verlauf ---------------- */
$$("#hist-game button").forEach((b) => b.onclick = () => { S.histGame = b.dataset.g; document.body.dataset.game = b.dataset.g; $$("#hist-game button").forEach((x) => x.classList.toggle("on", x === b)); loadHistory(); });
async function loadHistory() {
  const runs = (await api("/api/history?game=" + S.histGame)).slice().reverse();
  const body = $("#hist-body");
  if (!runs.length) { body.innerHTML = `<div class="empty"><h2>Noch kein Verlauf</h2><p>Sobald du einen Abend analysierst, landet er hier – mit Bestwerten und Entwicklung über die Wochen.</p></div>`; return; }
  const names = {}; runs.forEach((r) => Object.assign(names, r.summary.player_names || {}));
  const players = Object.keys(names).sort((a, b) => (names[a] || a).localeCompare(names[b] || b));
  const bossKeys = {}; runs.forEach((r) => Object.assign(bossKeys, r.summary.boss_names || {}));
  const table = runs.slice().reverse().map((r) => `<tr><td>${new Date(r.day + "T12:00").toLocaleDateString(LOC)}</td><td><b>${esc(r.title)}</b></td><td class="num">${r.summary.kills} / ${r.summary.bosses}</td><td class="num">${r.summary.deaths}</td>
    <td>${r.summary.goal_prev ? `<span class="st-${r.summary.goal_prev.status}">${{ ok: "✔", fail: "✘", partial: "~", open: "○" }[r.summary.goal_prev.status]}</span> ${r.summary.goal_prev.text}` : '<span class="cls">–</span>'}</td>
    <td><button class="btn small ghost" data-del="${r.id}">Löschen</button></td></tr>`).join("");
  const killRows = Object.entries(bossKeys).map(([k, n]) => `<tr><td>${esc(n)}</td>${runs.map((r) => `<td class="num">${r.summary.boss_kills?.[k] ? fmtDur(r.summary.boss_kills[k]) : '<span class="cls">–</span>'}</td>`).join("")}</tr>`).join("");
  body.innerHTML = `
    <div class="card"><h3>Entwicklung pro Spieler</h3><div class="row" style="margin-bottom:10px"><label>Spieler <select id="hist-player">${players.map((p) => `<option value="${esc(p)}">${esc(names[p] || p)}</option>`).join("")}</select></label><span class="muted">% vom ${S.histGame === "gw2" ? "Klassen-Median" : "Referenz-/Gruppenwert"} pro Abend</span></div><div id="hist-chart"></div></div>
    <div class="card scroll"><h3>Kill-Zeiten pro Abend</h3><table><tr><th>Boss</th>${runs.map((r) => `<th class="num">${new Date(r.day + "T12:00").toLocaleDateString(LOC, { day: "2-digit", month: "2-digit" })}</th>`).join("")}</tr>${killRows}</table></div>
    <div class="card"><h3>Gespeicherte Abende</h3><table><tr><th>Datum</th><th>Inhalt</th><th class="num">Kills</th><th class="num">Tode</th><th>Ziel vom letzten Mal</th><th></th></tr>${table}</table></div>`;
  const draw = () => { const p = $("#hist-player").value; $("#hist-chart").innerHTML = lineChart(runs.map((r) => ({ x: r.day, y: r.summary.player_pct?.[p] }))); };
  $("#hist-player").onchange = draw; draw();
  $$("[data-del]", body).forEach((b) => b.onclick = async () => { if (!confirm("Diesen Abend aus dem Verlauf löschen?")) return; await api("/api/history/delete", { id: b.dataset.del }); loadHistory(); });
}
function lineChart(pts) {
  const W = 900, H = 220, P = 36; const vals = pts.filter((p) => p.y != null);
  if (!vals.length) return '<p class="muted">Für diesen Spieler gibt es noch keine Werte.</p>';
  const max = Math.max(120, ...vals.map((p) => p.y)) * 1.05, min = 0;
  const x = (i) => P + (pts.length === 1 ? (W - 2 * P) / 2 : i * (W - 2 * P) / (pts.length - 1));
  const y = (v) => H - P + 10 - (v - min) / (max - min) * (H - P - 10);
  let path = "", dots = "";
  pts.forEach((p, i) => { if (p.y == null) return; path += (path ? "L" : "M") + x(i) + "," + y(p.y); dots += `<circle cx="${x(i)}" cy="${y(p.y)}" r="4.5" fill="var(--accent)"><title>${p.x}: ${p.y} %</title></circle><text x="${x(i)}" y="${y(p.y) - 9}" text-anchor="middle">${p.y} %</text>`; });
  const labels = pts.map((p, i) => `<text x="${x(i)}" y="${H - 6}" text-anchor="middle">${new Date(p.x + "T12:00").toLocaleDateString(LOC, { day: "2-digit", month: "2-digit" })}</text>`).join("");
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" width="100%"><line x1="${P}" x2="${W - P}" y1="${y(100)}" y2="${y(100)}" stroke="var(--muted)" stroke-dasharray="4 4" opacity=".6"/><text x="${P - 4}" y="${y(100) + 4}" text-anchor="end">100 %</text><path d="${path}" fill="none" stroke="var(--accent)" stroke-width="2.5"/>${dots}${labels}</svg>`;
}

/* ---------------- Einstellungen ---------------- */
const ROLES = ["auto", "DPS", "Quick", "Alac", "Heal", "Tank"];
async function renderSettings() {
  const s = S.settings; const body = $("#set-body");
  const hist = await api("/api/players").catch(() => []);
  const known = {};
  hist.forEach((p) => known[p.acc] = { name: p.name, last: p.last, count: p.count });
  (S.res.gw2?.summary.players || []).forEach((p) => known[p.acc] = { ...(known[p.acc] || { count: 0 }), name: p.name, last: known[p.acc]?.last || S.res.gw2.summary.day });
  Object.keys(s.roles || {}).concat(Object.keys(s.quips || {})).forEach((a) => known[a] = known[a] || { name: a, last: "", count: 0 });
  const hidden = new Set(s.hidden_players || []);
  const row = (a) => { const k = known[a]; return `<tr><td>${esc(k.name)}<br><span class="cls">${esc(a)}</span></td><td class="cls">${k.last ? new Date(k.last + "T12:00").toLocaleDateString(LOC) : "–"}${k.count ? ` · ${k.count} Abend${k.count > 1 ? "e" : ""}` : ""}</td>
    <td><select data-role="${esc(a)}">${ROLES.map((r) => `<option ${((s.roles || {})[a] || "auto") === r ? "selected" : ""}>${r}</option>`).join("")}</select></td>
    <td><input type="text" data-quip="${esc(a)}" value="${esc((s.quips || {})[a] || "")}" placeholder="optionaler Spruch für MVP/Ehrenpreis"></td>
    <td style="text-align:center"><input type="checkbox" data-hide="${esc(a)}" ${hidden.has(a) ? "checked" : ""} title="ausblenden"></td></tr>`; };
  const order = Object.keys(known).sort((a, b) => (known[b].last || "").localeCompare(known[a].last || "") || known[a].name.localeCompare(known[b].name));
  const head = '<tr><th>Spieler / Account</th><th>Zuletzt dabei</th><th style="width:120px">Rolle</th><th>Spruch</th><th style="width:80px">Ausblenden</th></tr>';
  const vis = order.filter((a) => !hidden.has(a)).map(row).join(""), hid = order.filter((a) => hidden.has(a)).map(row).join("");
  const roleRows = vis || hid;
  const refs = Object.entries(s.loa_refs || {});
  const refRows = refs.concat([["", {}]]).map(([k, v]) => `<tr><td><input type="text" data-ref-k value="${esc(k)}" placeholder="Boss|Normal"></td><td><input type="number" data-ref-dps value="${v.dps ?? ""}" placeholder="z. B. 500000000"></td><td><input type="number" data-ref-ap value="${v.ap ?? ""}" placeholder="z. B. 93"></td><td><input type="number" data-ref-dur value="${v.dur ?? ""}" placeholder="Sekunden"></td></tr>`).join("");
  body.innerHTML = `
    <div class="card"><h3>Ordner &amp; Dateien</h3><div class="set-grid">
      <label>arcdps-Logordner</label><input type="text" id="s-gw2" value="${esc(s.gw2_folder)}">
      <div class="hint">Dort legen arcdps und Elite Insights die Logs ab (Unterordner pro Boss).</div>
      <label>LOA-Logs-Datenbank</label><input type="text" id="s-loa" value="${esc(s.loa_db)}">
      <div class="hint">Standard: %LOCALAPPDATA%\\LOA Logs\\encounters.db – wird nur gelesen (als Kopie).</div>
      <label>PDF-Ordner</label><input type="text" id="s-pdf" value="${esc(s.pdf_folder)}">
      <label>Live-Modus prüft alle</label><span><input type="number" id="s-live" value="${s.live_interval}" min="10" style="width:80px"> Sekunden</span>
      <label>PDF-Druck über</label><span class="muted">${s._browser ? esc(s._browser) : "kein Edge/Chrome gefunden – PDFs gehen dann nicht"}</span>
    </div></div>
    <div class="card"><h3>Spieler: Rollen &amp; Sprüche (GW2)</h3>
      ${roleRows ? `<table class="kv">${head}${vis}</table>${hid ? `<details style="margin-top:10px"><summary class="muted" style="cursor:pointer">Ausgeblendete Spieler (${order.filter((a) => hidden.has(a)).length})</summary><table class="kv">${head}${hid}</table></details>` : ""}` : '<p class="muted">Nach der ersten GW2-Analyse erscheinen hier alle Spieler.</p>'}
      <div class="legend">Die Liste kommt aus deinen eigenen ausgewerteten Logs und wird nur auf diesem PC gespeichert. „auto“ erkennt Heal/Quick/Alac aus dem Log. Heal und Tank werden nicht am DPS-Median gemessen.</div></div>
    <div class="card"><h3>Gruppen-Zitat im PDF (optional)</h3><div class="set-grid">
      <label>Zitat</label><input type="text" id="s-q-text" value="${esc(s.quote_text)}" placeholder="leer = kein Zitat">
      <label>Von</label><input type="text" id="s-q-author" value="${esc(s.quote_author)}" placeholder="z. B. Name">
      <label>Bild</label><input type="text" id="s-q-img" value="${esc(s.quote_image)}" placeholder="optional: Pfad zu einem Bild (SVG, PNG, JPG)">
      <div class="hint">Das große Bild steht in der ausführlichen PDF vor dem Abschluss. Im Einseiter erscheint eine kleine Version neben dem Abschluss.</div>
      <label>Ausschnitt (nur SVG)</label><input type="text" id="s-q-crop" value="${esc(s.quote_crop)}" placeholder="optional, z. B. 110 20 450 650">
      <div class="hint">Welcher Teil des SVG-Bildes im Einseiter gezeigt wird (viewBox: x y Breite Höhe). Leer = ganzes Bild.</div>
    </div></div>
    <div class="card"><h3>Lost Ark: Referenzwerte (optional)</h3>
      <table class="kv"><tr><th>Boss|Schwierigkeit</th><th>Median-DPS (gesamt)</th><th>AP-Ziel %</th><th>Vergleichszeit (s)</th></tr>${refRows}</table>
      <div class="legend">Am einfachsten über den Lost-Ark-Tab: Gate öffnen → „Klassen-Median von lostark.bible“ → Text einfügen. Dann stehen hier auch die Werte pro Klasse (${Object.values(s.loa_refs || {}).reduce((n, r) => n + Object.keys(r.rows || {}).length, 0)} hinterlegt). Schlüssel genau wie im Programm angezeigt, z. B. <code>Belgardin, Arbiter of Death|Normal</code>. Ohne Werte vergleicht das Programm mit dem Gruppenschnitt.</div></div>
    <div class="card"><h3>Discord (optional)</h3><div class="set-grid">
      <label class="switch"><input type="checkbox" id="s-dc-on" ${s.discord_enabled ? "checked" : ""}><span></span> aktiv</label><input type="text" id="s-dc" value="${esc(s.discord_webhook)}" placeholder="https://discord.com/api/webhooks/…">
      <div class="hint">Webhook-Adresse aus den Kanal-Einstellungen in Discord (Integrationen → Webhooks). Ohne Webhook gibt es nur „Discord-Text kopieren“.</div>
    </div></div>
    <div class="card"><h3>KI (optional)</h3><div class="set-grid">
      <label class="switch"><input type="checkbox" id="s-ai-on" ${s.ai_enabled ? "checked" : ""}><span></span> aktiv</label><input type="password" id="s-ai-key" value="${esc(s.ai_key)}" placeholder="Anthropic-API-Schlüssel (sk-ant-…)">
      <label>Modell</label><input type="text" id="s-ai-model" value="${esc(s.ai_model)}">
      <div class="hint">Die KI bekommt nur die kleine, fertig gerechnete Zusammenfassung. API-Nutzung wird von Anthropic separat (pro Nutzung) abgerechnet – unabhängig von deinem Claude-Abo. Ohne Schlüssel: „KI-Zusammenfassung kopieren“ und im Chat einfügen.</div>
    </div></div>
    ${settings05(s)}
    <div class="actions"><button class="btn primary" id="s-save">Speichern</button><span class="muted" id="s-msg"></span></div>`;
  $("#s-save").onclick = saveSettings;
  bindSettings05();
}
async function saveSettings() {
  const roles = {}, quips = {}, refs = {}, hidden = [];
  $$("[data-hide]").forEach((el) => { if (el.checked) hidden.push(el.dataset.hide); });
  $$("[data-role]").forEach((el) => { if (el.value !== "auto") roles[el.dataset.role] = el.value; });
  $$("[data-quip]").forEach((el) => { if (el.value.trim()) quips[el.dataset.quip] = el.value.trim(); });
  $$("[data-ref-k]").forEach((el) => {
    const tr = el.closest("tr"); const k = el.value.trim(); if (!k) return;
    const num = (sel) => { const v = $(sel, tr).value; return v === "" ? undefined : Number(v); };
    refs[k] = { ...((S.settings.loa_refs || {})[k] || {}), dps: num("[data-ref-dps]"), ap: num("[data-ref-ap]"), dur: num("[data-ref-dur]") };
  });
  S.settings = await api("/api/settings", {
    gw2_folder: $("#s-gw2").value.trim(), loa_db: $("#s-loa").value.trim(), pdf_folder: $("#s-pdf").value.trim(),
    live_interval: Number($("#s-live").value) || 20, roles, quips, loa_refs: refs, hidden_players: hidden,
    quote_text: $("#s-q-text").value.trim(), quote_author: $("#s-q-author").value.trim(), quote_image: $("#s-q-img").value.trim(), quote_crop: $("#s-q-crop").value.trim(),
    discord_enabled: $("#s-dc-on").checked, discord_webhook: $("#s-dc").value.trim(),
    ai_enabled: $("#s-ai-on").checked, ai_key: $("#s-ai-key").value.trim(), ai_model: $("#s-ai-model").value.trim() || "claude-sonnet-5-5",
    ...readSettings05(),
  });
  S.settings._browser = (await api("/api/settings"))._browser;
  await renderSettings(); toast("Einstellungen gespeichert");
  if (S.res.gw2) renderResult("gw2"); if (S.res.loa) renderResult("loa");
}

/* ================================================================ 0.5 ================================================================ */
const dayLabel = (d, long) => new Date(d + "T12:00").toLocaleDateString(LOC, long ? { weekday: "short", day: "2-digit", month: "2-digit", year: "numeric" } : { day: "2-digit", month: "2-digit", year: "2-digit" });
function badgeHtml(b, who) {
  return `<div class="bdg" title="${esc(b.desc)}"><div class="sym">${esc(b.sym)}</div><div><b>${esc(b.name)}</b><span>${who ? esc(who) + " · " : ""}${esc(b.desc)}${b.first && b.last && b.first !== b.last ? ` · seit ${dayLabel(b.first)}` : b.last ? ` · ${dayLabel(b.last)}` : ""}</span></div></div>`;
}
const kpiBox = (l, v, n, t) => `<div class="kpi ${t || ""}"><div class="l">${esc(l)}</div><div class="v">${v}</div><div class="n">${esc(n || "")}</div></div>`;
const signed = (v, unit) => v == null ? "–" : (v > 0 ? "+" : v < 0 ? "−" : "±") + Math.abs(v) + (unit || "");

async function doExport(what) {
  try { const r = await job("/api/export", { what }, null); toast(`${r.files.length} CSV-Dateien gespeichert (Ordner Export)`); }
  catch (e) { toast(e.message); }
}

/* ---------------- dps.report-Upload (nur auf Klick) ---------------- */
async function uploadLogs(scope) {
  const r0 = S.res.gw2; if (!r0) return;
  if (r0.links) return toast("Diese Logs kommen schon von dps.report.");
  const encs = r0.encs.filter((e) => !scope || e.key === scope);
  const n = encs.reduce((k, e) => k + e.attempts.filter((a) => a.result !== "Reset" && !a.url).length, 0);
  if (!n) return toast("Alle Versuche haben schon einen dps.report-Link.");
  if (!confirm(`${n} Log${n > 1 ? "s" : ""} ${scope ? "von " + encs[0].title + " " : ""}jetzt zu dps.report hochladen?\n\nDie Logs sind danach über den Link für jeden sichtbar, der ihn hat.`)) return;
  const st = $("#gw2-status");
  try {
    const r = await job("/api/gw2/upload", { scope }, st);
    if (r.result) { S.res.gw2 = r.result; renderResult("gw2"); }
    setStatus(st, `${r.uploaded} hochgeladen` + (r.failed.length ? ` · ${r.failed.length} fehlgeschlagen: ${r.failed.join(" | ")}` : "") + (r.msg ? " · " + r.msg : ""), r.failed.length > 0);
    toast(r.uploaded ? "Hochgeladen – die Links stehen jetzt bei den Versuchen und im Discord-Text" : (r.msg || "Nichts hochgeladen"));
  } catch (e) { setStatus(st, e.message, true); }
}

/* ---------------- Spieler ---------------- */
S.pl = { list: [], acc: null, filter: "", cat: "", lastAcc: null };
async function loadPlayers() {
  S.pl.list = await api("/api/gw2/players").catch(() => []);
  if (!S.pl.list.length) {
    $("#pl-list").innerHTML = "";
    $("#pl-body").innerHTML = `<div class="empty"><h2>Noch keine Spieler</h2><p>Sobald du einen GW2-Abend analysierst, erscheint hier jeder Spieler mit seiner Entwicklung über alle Abende.</p></div>`;
    return;
  }
  if (!S.pl.acc || !S.pl.list.some((p) => p.acc === S.pl.acc)) S.pl.acc = S.pl.list[0].acc;
  renderPlayerList(); showPlayer(S.pl.acc);
}
function renderPlayerList() {
  const f = S.pl.filter.toLowerCase();
  $("#pl-list").innerHTML = `<input type="text" id="pl-filter" placeholder="Suchen …" value="${esc(S.pl.filter)}">` + S.pl.list.filter((p) => !f || (p.name + p.acc).toLowerCase().includes(f)).map((p) =>
    `<button class="pick ${p.acc === S.pl.acc ? "on" : ""}" data-acc="${esc(p.acc)}">${esc(p.name)}<small>${esc(p.acc)} · ${p.count} Abend${p.count > 1 ? "e" : ""} · zuletzt ${dayLabel(p.last)}${p.badges ? " · " + p.badges + " Abzeichen" : ""}</small></button>`).join("");
  const inp = $("#pl-filter"); inp.oninput = () => { S.pl.filter = inp.value; renderPlayerList(); const i2 = $("#pl-filter"); i2.focus(); i2.setSelectionRange(i2.value.length, i2.value.length); };
  $$("#pl-list .pick").forEach((b) => b.onclick = () => { S.pl.acc = b.dataset.acc; $$("#pl-list .pick").forEach((x) => x.classList.toggle("on", x === b)); showPlayer(b.dataset.acc); });
}
async function showPlayer(acc) {
  if (S.pl.lastAcc !== acc) { S.pl.lastAcc = acc; S.pl.cat = ""; }
  const p = await api("/api/gw2/player?acc=" + encodeURIComponent(acc) + (S.pl.cat ? "&cat=" + S.pl.cat : ""));
  const body = $("#pl-body");
  if (p.error) { if (S.pl.cat) { S.pl.cat = ""; return showPlayer(acc); } body.innerHTML = '<div class="empty"><h2>Keine Daten</h2></div>'; return; }
  const pcats = (p.cats || []).filter((c) => c !== "golem");
  const pbar = pcats.length > 1 ? `<div class="seg catbar">${["", ...pcats].map((c) => `<button data-pcat="${c}" class="${(S.pl.cat || "") === c ? "on" : ""}">${c ? CAT_LABEL[c] : "Alle"}</button>`).join("")}</div>` : "";
  const scope = p.cat ? "nur " + CAT_LABEL[p.cat] : "über alle Abende";
  const old = p.count - p.detailed;
  const bossRows = p.per_boss.map((b) => `<tr><td><b>${esc(b.title)}</b></td><td class="num">${b.times}</td><td>${b.best_pct != null ? meter(b.best_pct) : '<span class="cls">–</span>'}</td><td class="num">${b.avg_pct != null ? b.avg_pct + " %" : "–"}</td><td class="num">${fmtK(b.best_dps)}</td><td class="cls">${b.best_day ? dayLabel(b.best_day) + " · " + esc(b.best_prof || "") : ""}</td><td class="num">${b.deaths || "–"}</td></tr>`).join("");
  const evRows = p.evenings.slice().reverse().map((e) => `<tr><td>${dayLabel(e.day, true)}</td><td>${esc(e.title)}</td><td>${e.prof ? esc(e.prof) + (e.role && e.role !== "DPS" ? " · " + esc(e.role) : "") : '<span class="cls">–</span>'}</td><td>${e.pct != null ? meter(e.pct) : '<span class="cls">–</span>'}</td><td class="num">${e.deaths ?? "–"}</td><td class="num">${e.share != null ? e.share + " %" : "–"}</td></tr>`).join("");
  body.innerHTML = `
    <div class="hero"><div class="kicker">Spieler · ${esc(p.acc)}</div><h1>${esc(p.name)}</h1><div class="sub">${p.count} Abend${p.count > 1 ? "e" : ""} im Verlauf${p.cat ? " mit " + CAT_LABEL[p.cat] : ""} · ${p.profs.map(([c, n]) => `${esc(c)} (${n}×)`).join(", ") || "Klassen ab 0.5"}</div></div>
    ${pbar}
    <div class="kpis">
      ${kpiBox("Ø vom Klassen-Median", p.avg_pct != null ? p.avg_pct + " %" : "–", scope, p.avg_pct >= 100 ? "good" : p.avg_pct != null && p.avg_pct < 80 ? "bad" : "")}
      ${kpiBox("Bestwert", p.best_pct != null ? p.best_pct + " %" : "–", "bester Abend-Schnitt")}
      ${kpiBox("Trend", signed(p.trend, " Pkt"), "letzte 5 gegen 5 davor", p.trend > 0 ? "good" : p.trend < 0 ? "bad" : "")}
      ${kpiBox("Tode im Kill pro Abend", p.deaths_per_evening != null ? String(p.deaths_per_evening).replace(".", DEC) : "–", p.detailed ? `${p.deaths} insgesamt (ohne Wipes)` : "ab 0.5", p.deaths_per_evening > 1 ? "bad" : "")}
    </div>
    <div class="kpis">
      ${kpiBox("Beständigkeit", p.spread != null ? "±" + p.spread + " Pkt" : "–", p.steady || "ab 3 Abenden", p.spread != null && p.spread > 20 ? "bad" : p.spread != null && p.spread <= 10 ? "good" : "")}
      ${kpiBox("Ziele geschafft", p.goals_n ? `${p.goals_ok} / ${p.goals_n}` : "–", "persönliche Ziele", p.goals_n && p.goals_ok * 2 >= p.goals_n ? "good" : "")}
      ${kpiBox("Wiederbelebt", String(p.evenings.reduce((n, e) => n + (e.res || 0), 0)), "Mitspieler, alle Abende")}
      ${kpiBox("Ø Abstand Gruppe", (() => { const v = p.evenings.map((e) => e.dist).filter((x) => x != null); return v.length ? String(Math.round(v.reduce((a, b) => a + b, 0) / v.length)) : "–"; })(), "GW2-Einheiten")}
    </div>
    ${p.goal_now ? `<div class="card"><h3>Persönliches Ziel fürs nächste Mal</h3><p style="margin:0"><b>${esc(p.goal_now.text)}</b></p></div>` : ""}
    ${old ? `<div class="legend" style="margin:-6px 0 12px">${old} ältere${old > 1 ? "" : "r"} Abend${old > 1 ? "e" : ""} aus 0.4 ${old > 1 ? "haben" : "hat"} nur % vom Median. Für Tode, Klassen und Mechaniken den Abend im GW2-Tab einfach nochmal analysieren.</div>` : ""}
    <div class="card"><h3>Entwicklung über die Abende</h3><div id="pl-chart">${pctChart(p.evenings)}</div><div class="legend">Gold = % vom Wingman-Klassen-Median pro Abend, nach Kampfdauer gewichtet (in Klammern: Abstand zu 100 %) · grau gestrichelt = Median (100 %) · blau gepunktet = Schnitt der ganzen Gruppe am Abend · dünn gold = eigener Bestwert · grün = über Median, rot = darunter · höher ist besser</div></div>
    <div class="card"><h3>Abzeichen</h3>${p.badges.length ? `<div class="badges">${p.badges.map((b) => badgeHtml(b)).join("")}</div>` : '<p class="muted" style="margin:0">Noch keine – die kommen mit den nächsten Abenden.</p>'}</div>
    ${bossRows ? `<div class="card scroll"><h3>Pro Boss</h3><table><tr><th>Boss</th><th class="num">Abende</th><th>Bester Wert</th><th class="num">Ø</th><th class="num">Beste DPS</th><th>Wann · Klasse</th><th class="num">Tode</th></tr>${bossRows}</table><div class="legend">% vom Klassen-Median im Kill bzw. besten Versuch · Tode = Abende, an denen der Spieler bei dem Boss gestorben ist</div></div>` : ""}
    <div class="grid2b">
      <div class="card"><h3>Häufigste Todesursachen <span class="cls">alle Versuche, auch Wipes</span></h3>${p.causes.length ? `<div class="chips">${p.causes.map(([c, n]) => `<span class="chip">${esc(c)} <b>${n}×</b></span>`).join("")}</div>` : '<p class="muted" style="margin:0">Keine Tode erfasst.</p>'}</div>
      <div class="card"><h3>Meiste Mechanik-Treffer <span class="cls">alle Versuche</span></h3>${p.mechs.length ? `<div class="chips">${p.mechs.map(([c, n]) => `<span class="chip">${esc(c)} <b>${n}×</b></span>`).join("")}</div>` : '<p class="muted" style="margin:0">Nichts Nennenswertes.</p>'}</div>
    </div>
    <div class="card scroll"><h3>Alle Abende</h3><table><tr><th>Abend</th><th>Inhalt</th><th>Klasse</th><th>vs. Klassen-Median</th><th class="num">Tode im Kill</th><th class="num">Ø Anteil</th></tr>${evRows}</table>
      <div class="actions" style="margin:10px 0 0"><button class="btn small" id="pl-csv">Ganzen Verlauf als CSV</button></div></div>`;
  $("#pl-csv").onclick = () => doExport("verlauf");
  $$("[data-pcat]", body).forEach((b) => b.onclick = () => { S.pl.cat = b.dataset.pcat; showPlayer(acc); });
}

/* ---------------- Bosse + Wochen-Clears ---------------- */
S.boss = { list: [], key: null, cat: "all" };
async function loadBosses() {
  S.boss.list = await api("/api/gw2/bosses").catch(() => []);
  if (!S.boss.list.length) {
    $("#boss-list").innerHTML = "";
    $("#boss-body").innerHTML = `<div class="empty"><h2>Noch keine Bosse</h2><p>Nach den ersten Abenden siehst du hier pro Boss die Kill-Zeiten über die Wochen, Bestzeit, Wipes und woran ihr am öftesten scheitert.</p></div>`;
    return;
  }
  renderBossList();
  showBoss(S.boss.key);
}
function renderBossList() {
  // nach Art gruppiert (Raids nach Flügel, dann Strikes, Fraktale), oben Filter wenn mehrere Arten
  const cats = encCats(S.boss.list);
  if (!cats.includes(S.boss.cat)) S.boss.cat = "all";
  const shown = S.boss.list.filter((b) => S.boss.cat === "all" || (b.cat || "other") === S.boss.cat);
  if (!S.boss.key || !shown.some((b) => b.key === S.boss.key)) S.boss.key = shown[0].key;
  const bar = cats.length > 1 ? `<div class="seg catbar side-seg">${["all", ...cats].map((c) => `<button data-bcat="${c}" class="${S.boss.cat === c ? "on" : ""}">${c === "all" ? "Alle" : CAT_LABEL[c]}</button>`).join("")}</div>` : "";
  const item = (b) => `<button class="pick ${b.key === S.boss.key ? "on" : ""}" data-key="${esc(b.key)}">${esc(b.title)}<small>${b.evenings} Abend${b.evenings > 1 ? "e" : ""} · ${b.kills} Kill${b.kills !== 1 ? "s" : ""}${b.best_ms ? " · Bestzeit " + fmtDur(b.best_ms) : ""}</small></button>`;
  const body = cats.filter((c) => S.boss.cat === "all" || S.boss.cat === c).map((c) => {
    const xs = shown.filter((b) => (b.cat || "other") === c).sort((a, b) => (a.order || 0) - (b.order || 0) || a.title.localeCompare(b.title));
    let html = cats.length > 1 || c !== "other" ? `<div class="listgrp">${CAT_LABEL[c]}</div>` : "", last = null;
    xs.forEach((b) => { if (b.group && b.group !== last && c !== "other") { html += `<div class="listsub">${esc(b.group)}</div>`; last = b.group; } html += item(b); });
    return html;
  }).join("");
  $("#boss-list").innerHTML = bar + body;
  $$("#boss-list .pick").forEach((b) => b.onclick = () => { S.boss.key = b.dataset.key; $$("#boss-list .pick").forEach((x) => x.classList.toggle("on", x === b)); showBoss(b.dataset.key); });
  $$("[data-bcat]").forEach((b) => b.onclick = () => { S.boss.cat = b.dataset.bcat; const k = S.boss.key; renderBossList(); if (S.boss.key !== k) showBoss(S.boss.key); });
}
async function showBoss(key) {
  const b = await api("/api/gw2/boss?key=" + encodeURIComponent(key));
  const body = $("#boss-body");
  if (b.error) { body.innerHTML = '<div class="empty"><h2>Keine Daten</h2></div>'; return; }
  const med = b.rows.map((r) => r.wm_med_ms).filter(Boolean).pop();
  const rows = b.rows.slice().reverse().map((r) => `<tr><td>${dayLabel(r.day, true)}</td><td class="num">${fmtDur(r.kill_ms)}</td><td class="num">${fmtDur(r.wm_med_ms)}</td><td class="num ${r.kill_ms && r.wm_med_ms ? (r.kill_ms <= r.wm_med_ms ? "good" : "bad") : ""}">${r.kill_ms && r.wm_med_ms ? signed(Math.round((r.kill_ms - r.wm_med_ms) / 1000), " s") : "–"}</td><td class="num">${r.attempts ?? "–"}</td><td class="num">${r.wipes ?? "–"}</td><td class="num">${r.deaths ?? "–"}</td><td>${r.top ? `${esc(r.top.name)} <span class="cls">${r.top.pct} % · ${esc(r.top.prof)}</span>` : '<span class="cls">–</span>'}</td></tr>`).join("");
  body.innerHTML = `
    <div class="hero"><div class="kicker">Boss-Statistik</div><h1>${esc(b.title)}</h1><div class="sub">${b.evenings} Abend${b.evenings > 1 ? "e" : ""} · ${b.kills} Kill${b.kills !== 1 ? "s" : ""}</div></div>
    <div class="kpis">
      ${kpiBox("Bestzeit", fmtDur(b.best_ms), med ? "Median " + fmtDur(med) : "", b.best_ms && med ? (b.best_ms <= med ? "good" : "bad") : "")}
      ${kpiBox("Letzter Kill", fmtDur(b.last_ms), b.last_ms && b.best_ms && b.last_ms > b.best_ms ? signed(Math.round((b.last_ms - b.best_ms) / 1000), " s zur Bestzeit") : "Bestzeit!")}
      ${kpiBox("Ø Versuche", b.avg_attempts != null ? String(b.avg_attempts).replace(".", DEC) : "–", "pro Abend")}
      ${kpiBox("Wipes gesamt", String(b.wipes), "alle Abende", b.wipes > b.evenings * 2 ? "bad" : "")}
    </div>
    <div class="card"><h3>Kill-Zeit über die Abende</h3>${timeChart(b.rows)}<div class="legend">Gold = eure Kill-Zeit (in Klammern: Abstand zum Median) · grau gestrichelt = Wingman-Median · gepunktet = Wingman-Top-Log · dünn gold = eure Bestzeit · grün = schneller als Median, rot = langsamer · tiefer ist besser</div></div>
    <div class="grid2b">
      <div class="card"><h3>Woran ihr am öftesten scheitert</h3>${b.causes.length ? `<div class="chips">${b.causes.map(([c, n]) => `<span class="chip">${esc(c)} <b>${n} Tode</b></span>`).join("")}</div>` : '<p class="muted" style="margin:0">Keine Tode erfasst (ab 0.5).</p>'}
        ${b.mechs.length ? `<p class="muted" style="margin:12px 0 6px">Mechanik-Treffer gesamt</p><div class="chips">${b.mechs.map(([c, n]) => `<span class="chip">${esc(c)} <b>${n}×</b></span>`).join("")}</div>` : ""}</div>
      <div class="card"><h3>Wo die Zeit liegen bleibt</h3>${b.phase_avg.length ? `<table><tr><th>Phase</th><th class="num">Ø gegen Median</th><th class="num">Abende</th></tr>${b.phase_avg.map((p) => `<tr><td>${esc(p.name)}</td><td class="num ${p.avg_ms > 1000 ? "bad" : p.avg_ms < -1000 ? "good" : ""}">${signed(Math.round(p.avg_ms / 1000), " s")}</td><td class="num">${p.n}</td></tr>`).join("")}</table>` : '<p class="muted" style="margin:0">Phasen-Vergleich ab 0.5.</p>'}</div>
    </div>
    ${b.top_players.length ? `<div class="card"><h3>Beste Einzelleistungen</h3><table><tr><th>Spieler</th><th>Klasse</th><th>vs. Klassen-Median</th><th>Abend</th></tr>${b.top_players.map((t) => `<tr><td><b>${esc(t.name)}</b></td><td class="cls">${esc(t.prof)}</td><td>${meter(t.pct)}</td><td class="cls">${dayLabel(t.day)}</td></tr>`).join("")}</table></div>` : ""}
    <div class="card scroll"><h3>Alle Abende</h3><table><tr><th>Abend</th><th class="num">Kill-Zeit</th><th class="num">Median</th><th class="num">Differenz</th><th class="num">Versuche</th><th class="num">Wipes</th><th class="num">Tode</th><th>Top-DPS</th></tr>${rows}</table></div>`;
}
function timeChart(rows) {
  const pts = rows.filter((r) => r.kill_ms);
  if (!pts.length) return '<p class="muted">Noch kein Kill im Verlauf.</p>';
  const W = 900, H = 250, PL = 50, PR = 130, PT = 22, PB = 34;
  const med = pts.map((r) => r.wm_med_ms).filter(Boolean).pop();        // aktueller Wingman-Median
  const top = rows.map((r) => r.wm_top_ms).filter(Boolean).pop();        // Wingman-Bestzeit (Top-Log)
  const best = Math.min(...pts.map((r) => r.kill_ms));
  const vals = pts.map((r) => r.kill_ms).concat([med, top].filter(Boolean));
  const span = Math.max(...vals) - Math.min(...vals) || 30000;
  const max = Math.max(...vals) + span * 0.12, min = Math.min(...vals) - span * 0.12;
  const x = (i) => PL + (pts.length === 1 ? (W - PL - PR) / 2 : i * (W - PL - PR) / (pts.length - 1));
  const y = (v) => PT + (max - v) / (max - min) * (H - PT - PB);
  const x0 = PL, x1 = W - PR;
  let svg = "";
  // Fläche zwischen Kill-Zeit und Median: grün = schneller, rot = langsamer
  if (med) {
    const ym = y(med);
    const kx = pts.length === 1 ? [x(0) - 18, x(0) + 18] : null;
    const line = pts.length === 1 ? `M${kx[0]},${y(pts[0].kill_ms)}L${kx[1]},${y(pts[0].kill_ms)}` : pts.map((r, i) => `${i ? "L" : "M"}${x(i)},${y(r.kill_ms)}`).join("");
    const xa = pts.length === 1 ? kx[0] : x(0), xb = pts.length === 1 ? kx[1] : x(pts.length - 1);
    const area = `${line}L${xb},${ym}L${xa},${ym}Z`;
    const id = "c" + Math.random().toString(36).slice(2, 8);
    svg += `<defs><clipPath id="${id}a"><rect x="0" y="0" width="${W}" height="${ym}"/></clipPath><clipPath id="${id}b"><rect x="0" y="${ym}" width="${W}" height="${H}"/></clipPath></defs>
      <path d="${area}" fill="var(--bad)" opacity=".16" clip-path="url(#${id}a)"/><path d="${area}" fill="var(--ok)" opacity=".18" clip-path="url(#${id}b)"/>`;
  }
  // Referenzlinien über die ganze Breite + Beschriftung rechts (Abstand halten, damit nichts überlappt)
  const refs = [];
  if (med) refs.push({ v: med, label: "Median " + fmtDur(med), style: 'stroke="var(--muted)" stroke-width="2" stroke-dasharray="6 5"', col: "var(--muted)" });
  if (top) refs.push({ v: top, label: "Top-Log " + fmtDur(top), style: 'stroke="var(--accent2)" stroke-width="1.2" stroke-dasharray="2 4"', col: "var(--accent2)" });
  if (pts.length > 1) refs.push({ v: best, label: "Bestzeit " + fmtDur(best), style: 'stroke="var(--accent)" stroke-width="1" opacity=".7"', col: "var(--accent)" });
  refs.sort((a, b) => y(a.v) - y(b.v));
  let lastY = -99;
  refs.forEach((r) => {
    const ly = Math.max(y(r.v) + 4, lastY + 14); lastY = ly;
    svg += `<line x1="${x0}" x2="${x1}" y1="${y(r.v)}" y2="${y(r.v)}" ${r.style}/><text x="${x1 + 8}" y="${ly}" style="fill:${r.col}">${r.label}</text>`;
  });
  // Kill-Zeiten
  if (pts.length > 1) svg += `<path d="${pts.map((r, i) => `${i ? "L" : "M"}${x(i)},${y(r.kill_ms)}`).join("")}" fill="none" stroke="var(--accent)" stroke-width="2.5"/>`;
  pts.forEach((r, i) => {
    const d = r.wm_med_ms ? Math.round((r.kill_ms - r.wm_med_ms) / 1000) : null;
    const tag = d == null ? "" : ` <tspan style="fill:${d <= 0 ? "var(--ok)" : "var(--bad)"}">(${d > 0 ? "+" : d < 0 ? "−" : "±"}${fmtDur(Math.abs(d) * 1000)})</tspan>`;
    const above = !med || r.kill_ms >= med;   // Beschriftung von der Median-Linie weg
    svg += `<circle cx="${x(i)}" cy="${y(r.kill_ms)}" r="5" fill="var(--accent)"><title>${dayLabel(r.day)}: ${fmtDur(r.kill_ms)}</title></circle>
      <text x="${x(i)}" y="${y(r.kill_ms) + (above ? -11 : 19)}" text-anchor="middle" style="fill:var(--text)">${fmtDur(r.kill_ms)}${tag}</text>
      <text x="${x(i)}" y="${H - 10}" text-anchor="middle">${new Date(r.day + "T12:00").toLocaleDateString(LOC, { day: "2-digit", month: "2-digit" })}</text>`;
  });
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" width="100%">${svg}</svg>`;
}
function pctChart(evs) {
  const pts = evs.filter((e) => e.pct != null);
  if (!pts.length) return '<p class="muted">Für diesen Spieler gibt es noch keine Werte.</p>';
  const W = 900, H = 250, PL = 50, PR = 130, PT = 22, PB = 34;
  const best = Math.max(...pts.map((e) => e.pct));
  const vals = pts.map((e) => e.pct).concat(pts.map((e) => e.group_avg).filter((v) => v != null), [100]);
  const span = Math.max(...vals) - Math.min(...vals) || 20;
  const max = Math.max(...vals) + span * 0.15, min = Math.min(...vals) - span * 0.15;
  const x = (i) => PL + (pts.length === 1 ? (W - PL - PR) / 2 : i * (W - PL - PR) / (pts.length - 1));
  const y = (v) => PT + (max - v) / (max - min) * (H - PT - PB);
  const x0 = PL, x1 = W - PR, y100 = y(100);
  let svg = "";
  // Fläche zwischen Wert und 100 %: grün = über Median, rot = darunter
  const kx = pts.length === 1 ? [x(0) - 18, x(0) + 18] : null;
  const line = pts.length === 1 ? `M${kx[0]},${y(pts[0].pct)}L${kx[1]},${y(pts[0].pct)}` : pts.map((e, i) => `${i ? "L" : "M"}${x(i)},${y(e.pct)}`).join("");
  const xa = pts.length === 1 ? kx[0] : x(0), xb = pts.length === 1 ? kx[1] : x(pts.length - 1);
  const area = `${line}L${xb},${y100}L${xa},${y100}Z`;
  const id = "p" + Math.random().toString(36).slice(2, 8);
  svg += `<defs><clipPath id="${id}a"><rect x="0" y="0" width="${W}" height="${y100}"/></clipPath><clipPath id="${id}b"><rect x="0" y="${y100}" width="${W}" height="${H}"/></clipPath></defs>
    <path d="${area}" fill="var(--ok)" opacity=".18" clip-path="url(#${id}a)"/><path d="${area}" fill="var(--bad)" opacity=".16" clip-path="url(#${id}b)"/>`;
  // Gruppen-Schnitt pro Abend (Linie, bei einem Abend quer über die Breite)
  const gp = pts.map((e, i) => [i, e.group_avg]).filter((g) => g[1] != null);
  const refs = [{ v: 100, label: "Median 100 %", style: 'stroke="var(--muted)" stroke-width="2" stroke-dasharray="6 5"', col: "var(--muted)" }];
  if (pts.length > 1) refs.push({ v: best, label: `Bestwert ${best} %`, style: 'stroke="var(--accent)" stroke-width="1" opacity=".7"', col: "var(--accent)" });
  if (gp.length === 1 || (gp.length && pts.length === 1)) refs.push({ v: gp[0][1], label: `Gruppen-Ø ${gp[0][1]} %`, style: 'stroke="#6fa8ff" stroke-width="1.5" stroke-dasharray="2 4"', col: "#6fa8ff" });
  else if (gp.length > 1) {
    svg += `<path d="${gp.map(([i, v], k) => `${k ? "L" : "M"}${x(i)},${y(v)}`).join("")}" fill="none" stroke="#6fa8ff" stroke-width="1.5" stroke-dasharray="2 4"/>`;
    gp.forEach(([i, v]) => { svg += `<circle cx="${x(i)}" cy="${y(v)}" r="2.5" fill="#6fa8ff"><title>Gruppen-Ø ${v} %</title></circle>`; });
    const last = gp[gp.length - 1];
    refs.push({ v: last[1], label: `Gruppen-Ø ${last[1]} %`, noLine: true, col: "#6fa8ff" });
  }
  refs.sort((a, b) => y(a.v) - y(b.v));
  let lastY = -99;
  refs.forEach((r) => {
    const ly = Math.max(y(r.v) + 4, lastY + 14); lastY = ly;
    if (!r.noLine) svg += `<line x1="${x0}" x2="${x1}" y1="${y(r.v)}" y2="${y(r.v)}" ${r.style}/>`;
    svg += `<text x="${x1 + 8}" y="${ly}" style="fill:${r.col}">${r.label}</text>`;
  });
  if (pts.length > 1) svg += `<path d="${line}" fill="none" stroke="var(--accent)" stroke-width="2.5"/>`;
  pts.forEach((e, i) => {
    const d = e.pct - 100;
    const tag = ` <tspan style="fill:${d >= 0 ? "var(--ok)" : "var(--bad)"}">(${d > 0 ? "+" : d < 0 ? "−" : "±"}${Math.abs(d)} Pkt)</tspan>`;
    const above = e.pct >= 100;
    svg += `<circle cx="${x(i)}" cy="${y(e.pct)}" r="5" fill="var(--accent)"><title>${dayLabel(e.day)}: ${e.pct} %${e.group_avg != null ? " · Gruppen-Ø " + e.group_avg + " %" : ""}</title></circle>
      <text x="${x(i)}" y="${y(e.pct) + (above ? -11 : 19)}" text-anchor="middle" style="fill:var(--text)">${e.pct} %${tag}</text>
      <text x="${x(i)}" y="${H - 10}" text-anchor="middle">${new Date(e.day + "T12:00").toLocaleDateString(LOC, { day: "2-digit", month: "2-digit" })}</text>`;
  });
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" width="100%">${svg}</svg>`;
}
async function renderWeek(force) {
  const card = $("#week-card");
  const keys = (S.settings.gw2_api_keys || []).filter((k) => (k.key || "").trim());
  if (!keys.length) {
    card.innerHTML = `<h3>Wochen-Clears</h3><p class="muted" style="margin:0">Zeigt, welche Raid-Bosse diese Woche pro Account noch offen sind. Dafür in den Einstellungen einen GW2-API-Schlüssel (Berechtigung „progression“) eintragen – für mehrere Accounts einfach mehrere.</p>`;
    return;
  }
  card.innerHTML = `<h3>Wochen-Clears</h3><div class="status"><span class="spin"></span>Frage die GW2-API …</div>`;
  try {
    const w = await job("/api/gw2/weekly", {}, null);
    const accs = w.accounts;
    const hrs = Math.floor(w.reset_in_s / 3600), d = Math.floor(hrs / 24);
    let rows = "";
    w.wings.forEach((wing) => {
      const bosses = wing.events.filter((e) => e.type === "Boss");
      const openAny = bosses.some((e) => accs.some((a) => !a.error && !a.done.includes(e.id)));
      rows += `<tr class="wing"><td colspan="${accs.length + 1}">${esc(wing.name)}${openAny ? "" : " ✔"}</td></tr>`;
      bosses.forEach((e) => { rows += `<tr><td>${esc(e.name)}</td>${accs.map((a) => a.error ? '<td class="no">?</td>' : a.done.includes(e.id) ? '<td class="ok">✔</td>' : '<td class="no">○</td>').join("")}</tr>`; });
    });
    const tot = (a) => w.wings.flatMap((x) => x.events.filter((e) => e.type === "Boss")).filter((e) => a.done.includes(e.id)).length;
    const all = w.wings.flatMap((x) => x.events.filter((e) => e.type === "Boss")).length;
    card.innerHTML = `<h3>Wochen-Clears</h3>
      <div class="row" style="margin-bottom:10px">${accs.map((a) => `<span class="chip">${esc(a.label || a.name || "Account")}${a.name && a.label ? ` <span class="cls">${esc(a.name)}</span>` : ""}: ${a.error ? `<span class="bad">${esc(a.error)}</span>` : `<b>${tot(a)} / ${all}</b>`}</span>`).join("")}
        <span class="spacer"></span><span class="muted">Reset in ${d ? d + " " + UNITS.Tag + " " : ""}${hrs % 24} Std (${new Date(w.reset).toLocaleString(LOC, { weekday: "long", hour: "2-digit", minute: "2-digit" })} Uhr)</span><button class="btn small ghost" id="week-reload">Aktualisieren</button></div>
      <details ${force ? "open" : ""}><summary class="muted" style="cursor:pointer">Alle Raid-Bosse anzeigen</summary><div class="scroll" style="margin-top:8px"><table class="week"><tr><th>Boss</th>${accs.map((a) => `<th style="text-align:center">${esc(a.label || a.name)}</th>`).join("")}</tr>${rows}</table></div></details>
      <div class="legend">Offizielle GW2-API (nur Raids – für Strikes und Fraktale liefert die API keine Wochen-Clears). Stand: bis zu 1 Minute alt.</div>`;
    $("#week-reload").onclick = () => renderWeek(true);
  } catch (e) { card.innerHTML = `<h3>Wochen-Clears</h3><div class="status err">${esc(e.message)}</div>`; }
}

/* ---------------- Vergleich ---------------- */
S.cmp = { a: { src: "local", day: "", id: "", link: "" }, b: { src: "local", day: "", id: "", link: "" }, logs: {} };
function dayOptions(sel) {
  return $$("#gw2-day option").filter((o) => o.value).map((o) => `<option value="${esc(o.value)}" ${o.value === sel ? "selected" : ""}>${esc(o.textContent)}</option>`).join("");
}
async function logsFor(day) {
  if (!day) return [];
  if (!S.cmp.logs[day]) S.cmp.logs[day] = (await job("/api/gw2/logs", { day }, $("#cmp-status"))).logs;
  return S.cmp.logs[day];
}
async function renderCmpPick() {
  const first = $("#gw2-day option")?.value || "";
  ["a", "b"].forEach((k) => { if (!S.cmp[k].day) S.cmp[k].day = first; });
  const col = async (k) => {
    const c = S.cmp[k]; const logs = c.src === "local" ? await logsFor(c.day) : [];
    if (c.src === "local" && logs.length && !logs.some((l) => l.id === c.id)) c.id = (k === "b" ? (logs.find((l) => l.result === "Kill") || logs[0]) : logs[0]).id;
    return `<div class="card cmp-col"><h4><span class="ab ${k}">${k.toUpperCase()}</span>${k === "a" ? "Dieser Versuch" : "Vergleichen mit"}</h4>
      <div class="row"><div class="seg" data-src="${k}"><button data-v="local" class="${c.src === "local" ? "on" : ""}">Eigener Log</button><button data-v="link" class="${c.src === "link" ? "on" : ""}">dps.report-Link</button></div></div>
      ${c.src === "local" ? `<div class="row"><select data-day="${k}">${dayOptions(c.day)}</select></div>
        <div class="row"><select data-log="${k}">${logs.map((l) => `<option value="${esc(l.id)}" ${l.id === c.id ? "selected" : ""}>${esc(l.time)} · ${esc(l.boss)} · ${esc(l.result)} ${esc(l.dur)}</option>`).join("") || "<option value=''>keine Logs</option>"}</select></div>`
      : `<div class="row"><input type="text" data-link="${k}" value="${esc(c.link)}" placeholder="https://dps.report/… (z. B. ein Top-Log von Wingman)" style="flex:1;min-width:0"></div>
        <div class="legend">Tipp: Für „wie machen es die Besten“ bei GW2 Wingman einen Top-Log des Bosses öffnen und den dps.report-Link hier einfügen.</div>`}</div>`;
  };
  $("#cmp-pick").innerHTML = (await col("a")) + (await col("b"));
  $$("#cmp-pick [data-src] button").forEach((b) => b.onclick = () => { S.cmp[b.parentElement.dataset.src].src = b.dataset.v; renderCmpPick(); });
  $$("#cmp-pick [data-day]").forEach((el) => el.onchange = () => { S.cmp[el.dataset.day].day = el.value; S.cmp[el.dataset.day].id = ""; renderCmpPick(); });
  $$("#cmp-pick [data-log]").forEach((el) => el.onchange = () => { S.cmp[el.dataset.log].id = el.value; });
  $$("#cmp-pick [data-link]").forEach((el) => el.oninput = () => { S.cmp[el.dataset.link].link = el.value.trim(); });
}
function cmpSpec(k) { const c = S.cmp[k]; return c.src === "link" ? { link: c.link } : { day: c.day, id: c.id }; }
$("#cmp-swap").onclick = () => { [S.cmp.a, S.cmp.b] = [S.cmp.b, S.cmp.a]; renderCmpPick(); };
$("#cmp-go").onclick = async () => {
  const st = $("#cmp-status");
  for (const k of ["a", "b"]) { const sp = cmpSpec(k); if (sp.link === "" || (!sp.link && !sp.id)) return toast(`Bei ${k.toUpperCase()} fehlt noch der Log`); }
  try { const r = await job("/api/gw2/compare", { a: cmpSpec("a"), b: cmpSpec("b") }, st); st.textContent = ""; $("#cmp-result").innerHTML = cmpHtml(r); }
  catch (e) { st.innerHTML = `<span class="bad">${esc(e.message)}</span>`; }
};
function openCompare(a, b) {
  S.cmp.a = { src: "local", day: a.day, id: a.id, link: "" }; S.cmp.b = { src: "local", day: b.day, id: b.id, link: "" };
  showTab("cmp"); $("#cmp-result").innerHTML = "";
  setTimeout(() => $("#cmp-go").click(), 50);
}
function cmpRefOf(e) {
  const k = e.attempts.filter((a) => a.result === "Kill" && a.id).sort((x, y) => x.dur_ms - y.dur_ms)[0];
  return k ? { id: k.id, label: "dem Kill " + k.time } : null;
}
function cmpHtml(r) {
  const A = (t) => `<span class="ab a">A</span>${esc(t)}`, B = (t) => `<span class="ab b">B</span>${esc(t)}`;
  const kp = r.kpis.map((k) => `<tr><td>${esc(k.what)}</td><td class="num">${esc(k.a)}</td><td class="num">${esc(k.b)}</td><td class="num">${esc(k.diff)}</td></tr>`).join("");
  const ph = r.phases.map((p) => `<tr><td>${esc(p.name)}</td><td class="num">${esc(p.a)}</td><td class="num">${esc(p.b)}</td><td class="num ${p.tone}">${esc(p.diff)}</td></tr>`).join("");
  const one = (x) => x ? `<b>${esc(x.name)}</b> <span class="cls">${esc(x.prof)}${x.role !== "DPS" ? " · " + esc(x.role) : ""}</span>` : '<span class="cls">–</span>';
  const pl = r.players.map((p) => `<tr><td>${one(p.a)}</td><td class="num">${p.a ? p.a.dps_v + (p.a.pct != null ? ` <span class="cls">${p.a.pct} %</span>` : "") : "–"}${p.a && p.a.deaths ? ' <span class="dead">†</span>' : ""}</td>
    ${r.mode === "rang" ? `<td>${one(p.b)}</td>` : ""}<td class="num">${p.b ? p.b.dps_v + (p.b.pct != null ? ` <span class="cls">${p.b.pct} %</span>` : "") : "–"}${p.b && p.b.deaths ? ' <span class="dead">†</span>' : ""}</td><td class="num ${p.tone}">${esc(p.diff)}</td></tr>`).join("");
  const bo = r.boons.map((g) => `<tr><td><b>${esc(g.group)}</b></td>${["quick", "alac", "might"].map((k) => { const f = (v) => String(v).replace(".", DEC) + (k === "might" ? "" : " %"); return `<td class="num">${f(g.a[k])}</td><td class="num">${g.b ? f(g.b[k]) : "–"}</td>`; }).join("")}</tr>`).join("");
  return `
    <div class="hero"><div class="kicker">Vergleich${r.same_boss ? "" : " · Achtung: verschiedene Bosse"}</div><h1 style="font-size:20px">${A(r.a.label)}</h1><h1 style="font-size:20px">${B(r.b.label)}</h1></div>
    <div class="grid2b"><div class="card"><h3>Eckdaten</h3><table><tr><th></th><th class="num">A</th><th class="num">B</th><th class="num">A gegen B</th></tr>${kp}</table></div>
      <div class="card"><h3>Phasen</h3>${ph ? `<table><tr><th>Phase</th><th class="num">A</th><th class="num">B</th><th class="num">A gegen B</th></tr>${ph}</table>` : '<p class="muted" style="margin:0">Keine Phasen.</p>'}</div></div>
    <div class="card scroll"><h3>Spieler ${r.mode === "rang" ? "nach DPS-Rang" : "nebeneinander"}</h3><table><tr>${r.mode === "rang" ? "<th>A</th><th class='num'>Boss-DPS</th><th>B</th><th class='num'>Boss-DPS</th>" : "<th>Spieler</th><th class='num'>A Boss-DPS</th><th class='num'>B Boss-DPS</th>"}<th class="num">A gegen B</th></tr>${pl}</table>
      <div class="legend">${r.mode === "rang" ? "Unterschiedliche Spieler (z. B. fremder Top-Log) – deshalb Platz 1 neben Platz 1 usw." : "Gleiche Accounts nebeneinander"} · grau = % vom Klassen-Median · † = gestorben · grün/rot ab 3 % Unterschied</div></div>
    <div class="card scroll"><h3>Boon-Uptime pro Gruppe</h3><table><tr><th>Gruppe</th><th class="num">Quickness A</th><th class="num">B</th><th class="num">Alacrity A</th><th class="num">B</th><th class="num">Might A</th><th class="num">B</th></tr>${bo}</table></div>`;
}

/* ---------------- Einstellungen 0.5 ---------------- */
const OV_ITEMS = [["kill", "Letzter Versuch (Zeit vs. Median)"], ["top3", "Top-DPS"], ["deaths", "Tode im Versuch"], ["shame", "Mechanik-Magnet"], ["evening", "Abend-Stand + Abzeichen"]];
function settings05(s) {
  const keys = (s.gw2_api_keys || []).concat([{ label: "", key: "" }]);
  const ov = s.overlay || {}; const show = new Set(ov.show || []);
  const url = `http://127.0.0.1:${location.port}/overlay`;
  return `
    <div class="card"><h3>Wochen-Clears (GW2-API, optional)</h3>
      <table class="kv"><tr><th style="width:200px">Bezeichnung</th><th>API-Schlüssel</th></tr>${keys.map((k) => `<tr><td><input type="text" data-key-l value="${esc(k.label)}" placeholder="z. B. Hauptaccount"></td><td><input type="password" data-key-k value="${esc(k.key)}" placeholder="API-Schlüssel mit Berechtigung „progression“"></td></tr>`).join("")}</table>
      <div class="legend">Schlüssel erstellen: <a href="#" data-open="https://account.arena.net/applications" style="color:var(--accent)">account.arena.net → Anwendungen</a> → neuer Schlüssel mit „account“ und „progression“. Pro Account ein Schlüssel. Wird nur auf diesem PC gespeichert und nur an die offizielle GW2-API geschickt.</div></div>
    <div class="card"><h3>dps.report-Upload</h3><div class="set-grid">
      <label>User-Token (optional)</label><input type="password" id="s-dr-token" value="${esc(s.dpsreport_token || "")}" placeholder="leer = ohne Token hochladen">
      <div class="hint">Hochgeladen wird nur, wenn du auf „Logs zu dps.report hochladen“ klickst. Mit Token landen die Uploads in deinem dps.report-Verlauf (Token: dps.report → oben „User Token“).</div>
    </div></div>
    <div class="card"><h3>OBS-Overlay</h3><div class="set-grid">
      <label>Adresse für OBS</label><span class="row"><span class="overlay-url" id="ov-url">${esc(url)}</span><button class="btn small" id="ov-copy">Kopieren</button><button class="btn small ghost" id="ov-open">Vorschau</button></span>
      <div class="hint">OBS → Quelle hinzufügen → Browser → diese Adresse, Breite 460, Höhe 560. Der Hintergrund ist durchsichtig. Im Programm muss der <b>Live-Modus</b> an sein, dann aktualisiert sich das Overlay nach jedem Log von selbst.</div>
      <label>Anzeigen</label><span class="row">${OV_ITEMS.map(([k, l]) => `<label class="switch"><input type="checkbox" data-ov="${k}" ${show.has(k) ? "checked" : ""}><span></span> ${l}</label>`).join("")}</span>
      <label>Größe</label><span><input type="number" id="s-ov-scale" value="${ov.scale || 100}" min="50" max="250" style="width:80px"> % · Top-DPS: <input type="number" id="s-ov-top" value="${ov.top_n || 3}" min="1" max="10" style="width:60px"> Spieler</span>
    </div></div>
    <div class="card"><h3>Export</h3><div class="set-grid">
      <label>CSV-Trennzeichen</label><select id="s-sep" style="min-width:0;width:220px"><option value=";" ${s.export_sep !== "," ? "selected" : ""}>Semikolon (Excel deutsch)</option><option value="," ${s.export_sep === "," ? "selected" : ""}>Komma</option></select>
      <div class="hint">CSV-Dateien landen im Unterordner „Export“ des PDF-Ordners.</div>
    </div></div>
    <div class="card" id="about-card"><h3>Über &amp; Updates</h3><div class="set-grid">
      <label>Version</label><span><span class="about-ver" id="about-ver">…</span> <span class="muted" id="about-build"></span></span>
      <label>Sprache / Language</label><select id="s-lang" data-notr style="min-width:0;width:220px"><option value="">Windows (${window.NPG_LANG === "en" ? "English" : "Deutsch"})</option><option value="de" ${s.language === "de" ? "selected" : ""}>Deutsch</option><option value="en" ${s.language === "en" ? "selected" : ""}>English</option></select>
      <label>Update-Kanal</label><select id="s-upd-ch" style="min-width:0;width:220px"><option value="">Wie installiert</option><option value="beta" ${s.update_channel === "beta" ? "selected" : ""}>Beta (neueste Funktionen)</option><option value="stabil" ${s.update_channel === "stabil" ? "selected" : ""}>Stabil</option></select>
      <label class="switch"><input type="checkbox" id="s-upd-on" ${s.update_check !== false ? "checked" : ""}><span></span> Beim Start nach Updates suchen</label>
      <span class="row"><button class="btn small" id="upd-now">Jetzt nach Updates suchen</button><button class="btn small ghost" id="upd-page">Download-Seite</button><span class="muted" id="upd-status"></span></span>
      <div class="hint">Gesucht wird nur auf der NPG-Homepage. Installiert wird erst, wenn du auf „Jetzt aktualisieren“ klickst – deine Einstellungen und der Verlauf bleiben erhalten. Startet eine neue Version nicht, holt das Programm automatisch die vorige zurück.</div>
      <label>Fehler melden</label><span class="row"><button class="btn small" id="bug-zip">Fehlerbericht erstellen</button><span class="muted" id="bug-status"></span></span>
      <div class="hint">Erstellt eine ZIP-Datei auf dem Desktop (Protokoll, Version, Windows-Version, Einstellungen – Schlüssel, Token und Webhooks unkenntlich). Wohin du sie schickst, steht auf der Download-Seite.</div>
    </div>
    <p class="about-src">Quellen: arcdps (deltaconnected), Elite Insights, GW2 Wingman, dps.report, offizielle Guild-Wars-2-API, Nexus (Raidcore); Lost Ark: LOA Logs, Vergleichswerte von lostark.bible nur per Einfügen.<br>
    Fanprojekt von NerdPublic Gaming. Guild Wars 2 ist eine Marke von ArenaNet, LLC – kein offizielles Produkt von ArenaNet oder NCSOFT. Lost Ark ist eine Marke von Smilegate RPG.</p></div>`;
}
function bindSettings05() {
  $("#ov-copy").onclick = () => copy($("#ov-url").textContent);
  $("#ov-open").onclick = () => window.open("/overlay", "_blank", "width=480,height=600");
  $$("#set-body [data-open]").forEach((b) => b.onclick = (ev) => { ev.preventDefault(); api("/api/open_url", { url: b.dataset.open }).catch((e) => toast(e.message)); });
  api("/api/update").then((u) => {
    $("#about-ver").textContent = u.label; $("#about-build").textContent = `(${u.current}, Kanal ${u.channel === "stabil" ? "Stabil" : "Beta"})`;
    $("#upd-page").onclick = () => api("/api/open_url", { url: u.home });
  }).catch(() => {});
  $("#s-lang").onchange = async () => { await api("/api/settings", { language: $("#s-lang").value }); location.reload(); };
  $("#upd-now").onclick = async () => {
    $("#upd-status").textContent = "Suche …";
    try {
      const u = await api("/api/update?force=1");
      $("#upd-status").textContent = !u.online ? "Homepage nicht erreichbar." : u.update ? `Version ${u.update.label} verfügbar (siehe oben).` : "Du hast die neueste Version.";
      if (u.update) showUpdate(u);
    } catch (e) { $("#upd-status").textContent = e.message; }
  };
  $("#bug-zip").onclick = async () => {
    $("#bug-status").textContent = "Erstelle …";
    try { const r = await api("/api/support/report", {}); $("#bug-status").textContent = "Gespeichert: " + r.path; }
    catch (e) { $("#bug-status").textContent = e.message; }
  };
}
function readSettings05() {
  const keys = [];
  $$("[data-key-k]").forEach((el) => { const k = el.value.trim(); if (k) keys.push({ label: el.closest("tr").querySelector("[data-key-l]").value.trim(), key: k }); });
  return {
    gw2_api_keys: keys, dpsreport_token: $("#s-dr-token").value.trim(), export_sep: $("#s-sep").value,
    overlay: { show: $$("[data-ov]").filter((x) => x.checked).map((x) => x.dataset.ov), scale: Number($("#s-ov-scale").value) || 100, top_n: Number($("#s-ov-top").value) || 3 },
    update_check: $("#s-upd-on").checked, update_channel: $("#s-upd-ch").value, language: $("#s-lang").value,
  };
}
async function checkUpdate() {
  try {
    const u = await api("/api/update");
    if (u.just_updated) toast(`Aktualisiert auf Version ${u.label} ✓`);
    if (u.failed) {
      const bar = $("#update-bar"); bar.classList.remove("hidden"); bar.classList.add("warn");
      bar.innerHTML = `<b>Das Update auf ${esc(u.failed)} ist nicht gestartet</b> – die vorige Version wurde wiederhergestellt. <span class="muted">Bitte über Einstellungen → „Fehlerbericht erstellen“ melden.</span>`;
      return;
    }
    if (u.update) showUpdate(u);
  } catch {}
}
function showUpdate(u) {
  const up = u.update, bar = $("#update-bar");
  bar.classList.remove("hidden", "warn");
  const notes = (up.notes || []).slice(0, 6).map((n) => `<li>${esc(n)}</li>`).join("");
  if (up.needs_full || u.dev) {
    bar.innerHTML = `<b>Neue Version ${esc(up.label)}</b> verfügbar – ${u.dev ? "Entwicklungsordner: wird nicht automatisch ersetzt." : "braucht das Komplett-Paket."} <button class="btn small" id="upd-open">Download-Seite öffnen</button>${notes ? `<ul class="notes">${notes}</ul>` : ""}`;
    $("#upd-open").onclick = () => api("/api/open_url", { url: up.page });
    return;
  }
  bar.innerHTML = `<b>Neue Version ${esc(up.label)}</b>${up.date ? ` <span class="muted">vom ${esc(up.date.split("-").reverse().join("."))}</span>` : ""} <button class="btn small" id="upd-go">Jetzt aktualisieren</button>
    <span id="upd-msg" class="muted"></span><span class="upd-prog hidden" id="upd-prog"><i style="width:0"></i></span>${notes ? `<ul class="notes">${notes}</ul>` : ""}`;
  $("#upd-go").onclick = async () => {
    $("#upd-go").disabled = true; $("#upd-prog").classList.remove("hidden");
    await api("/api/update/install", {});
    const tick = async () => {
      const j = await api("/api/update/job");
      $("#upd-msg").textContent = j.msg || ""; $("#upd-prog i").style.width = (j.pct || 0) + "%";
      if (j.state === "running") return setTimeout(tick, 400);
      if (j.state === "error") { $("#upd-go").disabled = false; $("#upd-prog").classList.add("hidden"); return; }
      if (j.state === "ready") {
        $("#upd-go").outerHTML = `<button class="btn small" id="upd-restart">Neu starten</button>`; $("#upd-prog").classList.add("hidden");
        $("#upd-restart").onclick = async () => {
          $("#upd-msg").textContent = "Programm startet neu …";
          try { await api("/api/update/restart", {}); } catch (e) { $("#upd-msg").textContent = e.message; return; }
          setTimeout(() => { try { window.close(); } catch {} document.body.innerHTML = '<p style="padding:40px;font-size:18px">Das Programm startet neu – dieses Fenster kann geschlossen werden.</p>'; }, 1500);
        };
      }
    };
    tick();
  };
}

/* ================================================================ 0.6: tiefere Analyse ================================================================ */
const de1 = (v) => v == null ? "–" : String(v).replace(".", DEC);
const relCls = (r) => r == null ? "" : r >= 110 ? "best" : r < 75 ? "worst" : "";

function costsCard(e) {
  const c = e.costs; if (!c) return "";
  const lines = (c.lines || []).map((x) => `<tr><td><b>${esc(x.name)}</b></td><td class="num">${x.dead_s ? x.dead_s + " s" : "–"}</td><td class="num">${x.downed_s ? x.downed_s + " s" : "–"}</td><td class="num">${esc(x.lost_v)}</td></tr>`).join("");
  return `<div class="card"><h3>Was hat Zeit gekostet?</h3>
    ${e.verdict ? `<p style="margin:0 0 12px">${e.verdict}</p>` : ""}
    <div class="kpis" style="margin-bottom:10px">
      ${kpiBox("Tode & Downs", (c.death_s || 0) + " s", "Kill-Zeit durch Ausfälle", c.death_s > 10 ? "bad" : "")}
      ${kpiBox("Mit Median-DPS", c.whatif || "–", c.whatif ? `Squad ${c.squad} → ${c.hypo}` : "nur bei Kills")}
      ${kpiBox("Fehlender Schaden", esc(c.lost_v || "–"), "durch Tode/Downs")}
      ${kpiBox("Kill-Zeit", fmtDur(e.best_kill_ms), e.wm_med_ms ? "Median " + fmtDur(e.wm_med_ms) : "")}
    </div>
    ${lines ? `<table><tr><th>Spieler</th><th class="num">Tot</th><th class="num">Down</th><th class="num">Fehlender Schaden</th></tr>${lines}</table>` : '<p class="muted" style="margin:0">Niemand war nennenswert tot oder down.</p>'}
    <div class="legend">Fehlender Schaden = eigene DPS im Leben × Zeit tot/down. „Mit Median-DPS“ = gleicher Kampf, aber ohne Ausfälle und jeder DPS-/Boon-Spieler genau auf dem Wingman-Klassen-Median (Heal/Tank bleiben gleich). Grobe Schätzung, keine Simulation.</div></div>`;
}
function phaseDpsCard(e) {
  const t = e.phase_dps; if (!t) return "";
  const rows = t.rows.map((r) => `<tr><td><b>${esc(r.name)}</b> <span class="cls">${esc(r.prof)}${r.role !== "DPS" ? " · " + esc(r.role) : ""}</span></td>${r.cells.map((c) => `<td class="${relCls(c.rel)}" title="${c.rel != null ? c.rel + " % vom Gruppen-Median in dieser Phase" : ""}">${esc(c.v)}${c.down ? '<span class="dead"> ↓</span>' : ""}</td>`).join("")}</tr>`).join("");
  return `<div class="card scroll"><h3>DPS pro Phase</h3><table class="prog"><tr><th>Spieler</th>${t.cols.map((c) => `<th>${esc(c.name)}<br><span class="cls">${esc(c.dur)}</span></th>`).join("")}</tr>${rows}
    <tr><td><b>Squad</b></td>${t.squad.map((v) => `<td><b>${esc(v)}</b></td>`).join("")}</tr></table>
    ${t.notes.length ? `<ul style="margin-top:10px">${t.notes.map((n) => `<li>${n}</li>`).join("")}</ul>` : ""}
    <div class="legend">Boss-DPS in jeder Phase (in Split-Phasen auf die Adds) · grün = über 110 %, rot = unter 75 % vom Median der DPS-Spieler in derselben Phase · ↓ = in der Phase down gegangen</div></div>`;
}
function boonPhaseCard(e) {
  const t = e.boon_phases; if (!t) return "";
  const cell = (v) => v == null ? '<td class="cls">–</td>' : `<td class="num ${v >= 90 ? "good" : v < 75 ? "bad" : ""}">${v} %</td>`;
  const rows = t.rows.map((r) => `<tr><td rowspan="2"><b>${esc(r.group)}</b><br><span class="cls">${esc(r.members)}</span></td><td class="cls">Quickness</td>${r.cells.map((c) => cell(c.q)).join("")}</tr><tr><td class="cls">Alacrity</td>${r.cells.map((c) => cell(c.a)).join("")}</tr>`).join("");
  return `<div class="card scroll"><h3>Boon-Uptime pro Phase</h3><table><tr><th>Gruppe</th><th></th>${t.cols.map((c) => `<th class="num">${esc(c)}</th>`).join("")}</tr>${rows}</table>
    ${t.drops.length ? `<p class="muted" style="margin:10px 0 0"><b>Einbrüche:</b> ${t.drops.map(esc).join(" · ")}</p>` : ""}
    <div class="legend">Uptime im Schnitt der Untergruppe je Phase (wer in der Phase tot war, zählt nicht mit) · grün ab 90 %, rot unter 75 % · Einbrüche direkt nach Phasenwechseln deuten auf Laufwege oder verstreute Gruppe hin</div></div>`;
}
function breakbarCard(e) {
  const b = e.breakbars; if (!b) return "";
  const rows = b.rows.map((r) => `<tr><td>${esc(r.name)}</td><td class="num">${esc(r.at)}</td><td class="num">${de1(r.dur)} s</td><td class="num">${r.med != null ? (r.approx ? "≈ " : "") + de1(r.med) + " s" : "–"}</td><td class="num ${r.tone}">${r.diff != null ? (r.diff > 0 ? "+" : r.diff < 0 ? "−" : "±") + de1(Math.abs(r.diff)) + " s" : "–"}</td></tr>`).join("");
  return `<div class="card"><h3>Breakbar-Tempo</h3><table><tr><th>Breakbar</th><th class="num">bei</th><th class="num">gebrochen nach</th><th class="num">Median</th><th class="num">Differenz</th></tr>${rows}</table>
    <div class="legend">Wie lange die Defiance-Leiste gebraucht hat · ${b.lost ? `zusammen <b>${de1(b.lost)} s</b> langsamer als der Median · ` : ""}${b.approx ? "≈ = deutscher Log, Wingman-Median über das Nummern-Muster zugeordnet (z. B. alle „Wächter 1 CC 1“ gemittelt)" : "Median von GW2 Wingman"}</div></div>`;
}
function positionCard(e) {
  const t = e.positioning; if (!t) return "";
  const rows = t.rows.map((r) => `<tr><td><b>${esc(r.name)}</b> <span class="cls">${esc(r.prof)}${r.role !== "DPS" ? " · " + esc(r.role) : ""} · Gr. ${r.group}</span></td>
    <td class="num ${r.far ? "bad" : ""}">${r.dist_squad ?? "–"}</td><td class="num">${r.is_com ? '<span class="cls">Kommandeur</span>' : (r.dist_com ?? "–")}</td>
    <td class="num">${r.cleanses || "–"}</td><td class="num">${r.strips || "–"}</td><td class="num">${r.res ? r.res + ` <span class="cls">(${de1(r.res_s)} s)</span>` : "–"}</td>
    <td class="num">${r.downed_s ? r.downed_s + " s" : "–"}</td><td class="num">${r.dead_s ? `<span class="dead">${r.dead_s} s</span>` : "–"}</td><td class="num">${r.anim != null ? r.anim + " %" : "–"}</td></tr>`).join("");
  return `<div class="card scroll"><h3>Positionierung &amp; Support</h3><table><tr><th>Spieler</th><th class="num">Ø Abstand Gruppe</th><th class="num">Ø Abstand Kommandeur</th><th class="num">Cleanses</th><th class="num">Boon-Strips</th><th class="num">Wiederbelebt</th><th class="num">Zeit down</th><th class="num">Zeit tot</th><th class="num">Zeit in Animation</th></tr>${rows}</table>
    <div class="legend">Abstand in GW2-Einheiten (wie Elite Insights) · rot = deutlich weiter weg als der Rest (Median ${t.med_squad ?? "–"}) – weit weg heißt oft: keine Boons, keine Heilung · Abstand Kommandeur nur aussagekräftig, wenn der Kommandeur-Tag beim Spieler liegt, der die Gruppe positioniert${t.commander ? ` (hier: ${esc(t.commander)})` : ""} · Zeit in Animation = Anteil der Kampfzeit, in der Skills gewirkt wurden</div></div>`;
}
function sourcesCard(e) {
  const t = e.dmg_sources; if (!t || !t.length) return "";
  return `<div class="card"><h3>Größte Schadensquellen</h3><table><tr><th>Quelle</th><th class="num">Schaden gesamt</th><th class="num">Treffer</th><th>Am meisten</th></tr>
    ${t.map((x) => `<tr><td>${esc(x.name)}</td><td class="num">${esc(x.dmg)}</td><td class="num">${x.hits}</td><td>${esc(x.top)} <span class="cls">${x.top_share} % · ${x.players} Spieler getroffen</span></td></tr>`).join("")}</table>
    <div class="legend">Kassierter Schaden im Kill bzw. besten Versuch nach Skill. Elite Insights unterscheidet nicht zwischen vermeidbar und unvermeidbar (z. B. Auren treffen immer) – wenn einer bei einer Quelle deutlich mehr abbekommt als der Rest, lohnt sich ein Blick.</div></div>`;
}
function timelineSvg(t, maxDur) {
  const W = 900, H = 64, L = 8, R = 8, w = W - L - R;
  const x = (ms) => L + ms / maxDur * w;
  let s = `<rect x="${L}" y="18" width="${x(t.dur_ms) - L}" height="18" rx="3" fill="rgba(255,255,255,.06)"/>`;
  t.phases.forEach((p, i) => {
    s += `<rect x="${x(p.start)}" y="18" width="${Math.max(1, x(p.start + p.dur) - x(p.start))}" height="18" rx="3" fill="${/^phase/i.test(p.name) ? "rgba(216,178,106,.28)" : "rgba(142,151,173,.25)"}"><title>${esc(p.name)} · ${fmtDur(p.dur)}${t.downs[i] ? " · " + t.downs[i] + " Downs" : ""}</title></rect>`;
    if (x(p.start + p.dur) - x(p.start) > 46) s += `<text x="${x(p.start) + 4}" y="31" style="font-size:10.5px;fill:var(--text)">${esc(p.name)}${t.downs[i] ? " ↓" + t.downs[i] : ""}</text>`;
  });
  t.deaths.forEach((d) => { s += `<g><line x1="${x(d.t)}" x2="${x(d.t)}" y1="12" y2="42" stroke="var(--bad)" stroke-width="2"/><circle cx="${x(d.t)}" cy="10" r="4" fill="var(--bad)"/><title>† ${esc(d.name)} bei ${esc(d.at)} – ${esc(d.cause)}</title></g>`; });
  s += `<line x1="${x(t.dur_ms)}" x2="${x(t.dur_ms)}" y1="14" y2="40" stroke="${t.result === "Kill" ? "var(--ok)" : "var(--bad)"}" stroke-width="3"/><text x="${Math.min(x(t.dur_ms) + 5, W - 60)}" y="56" style="font-size:11px">${t.result === "Kill" ? "Kill " + esc(t.dur) : esc(t.dur) + " · " + t.hp_left + " % übrig"}</text>`;
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" width="100%">${s}</svg>`;
}
function timelineCard(e) {
  const ts = e.timelines; if (!ts || !ts.length) return "";
  const maxDur = Math.max(...ts.map((t) => t.dur_ms));
  return `<div class="card"><h3>Zeitleiste pro Versuch</h3>${ts.map((t) => `<div style="margin-bottom:8px"><div class="row" style="gap:8px"><span class="badge b-${t.result}">${t.result}</span><b>${esc(t.time)}</b><span class="cls">${t.trigger ? t.trigger : "keine Tode"}</span></div>${timelineSvg(t, maxDur)}</div>`).join("")}
    <div class="legend">Gold = Boss-Phasen, grau = Splits/Adds · rote Striche = Tode (Maus drüber für Name und Ursache) · ↓n = Downs in der Phase · gleicher Maßstab für alle Versuche</div></div>`;
}
async function showRotation(e, acc, btn) {
  const out = $("#rot-out"); const p = e.players.find((x) => x.acc === acc);
  out.innerHTML = `<div class="card"><h3>Rotation: ${esc(p.name)} gegen Top-Log</h3><div class="status"><span class="spin"></span>Hole den besten ${esc(p.prof)}-Log von Wingman …</div></div>`;
  out.scrollIntoView({ behavior: "smooth", block: "nearest" });
  // Hinweis mit Knöpfen, wenn Wingman nur eine Vorschau hat: Nutzer drückt dort selbst „Reparse for Full Report“
  const wmHint = (r) => r.previews && r.previews.length ? `<div class="wm-hint">Für den echten Top-Log: <button class="btn small" data-open="${esc(r.previews[0])}">Auf Wingman öffnen ↗</button> dort „Reparse for Full Report“ drücken, kurz warten, dann <button class="btn small" data-retry>Nochmal versuchen</button></div>` : "";
  const wire = () => {
    $$("[data-open]", out).forEach((b) => b.onclick = (ev) => { ev.preventDefault(); api("/api/open_url", { url: b.dataset.open }).catch((er) => toast(er.message)); });
    $$("[data-retry]", out).forEach((b) => b.onclick = () => showRotation(e, acc, btn));
  };
  try {
    const r = await job("/api/gw2/rotation", { log: e.target_id, acc }, out.querySelector(".status"));
    if (r.none) {
      out.innerHTML = `<div class="card"><h3>Rotation: ${esc(r.name)} (${esc(r.prof)})</h3><p style="margin:0 0 6px">${esc(r.why)}</p><p class="muted" style="margin:0">${esc(r.msg)}</p>${wmHint(r)}</div>`;
      wire(); return;
    }
    const own = r.src === "own"; const ref = own ? "Vergleich" : "Top-Log";
    const rows = r.rows.map((x) => `<tr><td>${esc(x.name)}</td><td class="num">${de1(x.ours)}</td><td class="num">${de1(x.top)}</td><td class="num ${x.tone}">${x.diff > 0 ? "+" : x.diff < 0 ? "−" : "±"}${de1(Math.abs(x.diff))}</td><td>${x.missing ? '<span class="bad">fehlt</span>' : ""}</td></tr>`).join("");
    const link = r.top_url ? ` (<a href="#" data-open="${esc(r.top_url)}" style="color:var(--accent)">ansehen</a>)` : "";
    out.innerHTML = `<div class="card"><h3>Rotation: ${esc(r.name)} (${esc(r.prof)}) gegen ${own ? "euren besten eigenen Log" : "Top-Log"}</h3>
      ${own ? `<div class="wm-note">${esc(r.ref_text)}</div>` : ""}${wmHint(r)}
      <div class="kpis">${kpiBox("Boss-DPS", esc(r.ours_dps), ref + " " + r.top_dps)}${kpiBox("Casts pro Minute", de1(r.ours_cpm), ref + " " + de1(r.top_cpm))}${kpiBox("Zeit in Animation", r.ours_anim != null ? Math.round(r.ours_anim) + " %" : "–", r.top_anim != null ? ref + " " + Math.round(r.top_anim) + " %" : "")}${kpiBox("Kampfdauer", esc(r.ours_dur), ref + " " + r.top_dur)}</div>
      ${r.notes.length ? `<ul style="margin:0 0 10px">${r.notes.map((n) => `<li>${n}</li>`).join("")}</ul>` : ""}
      <table><tr><th>Skill</th><th class="num">Du / Minute</th><th class="num">${ref} / Minute</th><th class="num">Differenz</th><th></th></tr>${rows}</table>
      <div class="legend">${own ? `Vergleich: ${esc(r.top_name)} – bester ${esc(r.prof)} bei ${esc(r.boss)} aus euren eigenen Logs${link}. Nur Kills aus Abenden, die das Programm schon einmal eingelesen hat.`
        : `Top-Log: ${esc(r.top_name)} – bester ${esc(r.prof)}-Log bei ${esc(r.boss)} laut GW2 Wingman${link}. Ein Top-Log ist meist ein Speedrun mit perfekten Boons, also als Richtung verstehen, nicht als Pflicht.`} Casts pro Minute über den ganzen Kampf. Skill-Namen aus deinem Log (deutsch), fremde Skills auf Englisch. Sigil-, Relikt- und Trait-Procs sind ausgeblendet.</div></div>`;
    wire();
  } catch (er) { out.innerHTML = `<div class="card"><h3>Rotation</h3><div class="status err">${esc(er.message)}</div></div>`; }
}
function goalsCard(s) {
  const pl = s.players.filter((p) => p.goal_next || p.goal_prev);
  if (!pl.length) return "";
  const st = { ok: "✔ geschafft", fail: "✘ verfehlt", partial: "~ knapp", open: "○ offen" };
  return `<div class="card scroll"><h3>Persönliche Ziele</h3><table><tr><th>Spieler</th><th>Ziel vom letzten Mal</th><th>Ergebnis</th><th>Ziel fürs nächste Mal</th></tr>
    ${pl.map((p) => `<tr><td><b>${esc(p.name)}</b></td><td>${p.goal_prev ? esc(p.goal_prev.text) : '<span class="cls">–</span>'}</td><td>${p.goal_prev ? `<span class="st-${p.goal_prev.status}">${st[p.goal_prev.status]}</span> <span class="cls">${esc(p.goal_prev.detail || "")}</span>` : ""}</td><td>${p.goal_next ? esc(p.goal_next.text) : "–"}</td></tr>`).join("")}</table>
    <div class="legend">Pro Spieler das eine wichtigste Ding (Food/Utility → Tode → Boon-Generation → % vom Median) · wird beim nächsten Abend automatisch geprüft · geschafft = Abzeichen „Ziel erreicht“</div></div>`;
}

/* ---------------- Golem-Training ---------------- */
S.golem = { data: null, key: null };
async function loadGolem(force) {
  const st = $("#golem-status");
  if (S.golem.data && !force) return renderGolem();
  try {
    S.golem.data = await job("/api/golem/load", {}, st);
    setStatus(st, `${S.golem.data.attempts.length} Versuch${S.golem.data.attempts.length !== 1 ? "e" : ""} aus ${S.golem.data.logs} Golem-Log${S.golem.data.logs !== 1 ? "s" : ""}`);
    renderGolem();
  } catch (e) { setStatus(st, e.message, true); }
}
$("#golem-go").onclick = () => loadGolem(true);
$("#golem-sc").onclick = () => api("/api/open_url", { url: "https://snowcrows.com/benchmarks" }).catch((e) => toast(e.message));
function renderGolem() {
  const d = S.golem.data; const body = $("#golem-body");
  if (!d.specs.length) {
    body.innerHTML = `<div class="empty"><h2>Keine Golem-Logs gefunden</h2><p>arcdps legt Golem-Logs in einen eigenen Ordner wie „Standard Kitty Golem“ im Log-Ordner. Damit sie hier erscheinen, muss Elite Insights sie – wie die Raid-Logs – als HTML speichern. Versuche unter 15 Sekunden werden nicht gezählt.</p></div>`;
    return;
  }
  if (!S.golem.key || !d.specs.some((s) => s.key === S.golem.key)) S.golem.key = d.specs[0].key;
  const rows = d.specs.map((s) => `<tr class="clickrow ${s.key === S.golem.key ? "sel" : ""}" data-gk="${esc(s.key)}">
      <td><b>${esc(s.prof)}</b><br><span class="cls">${esc(s.name)} · ${esc(s.acc)}</span></td><td class="num">${s.n}</td>
      <td class="num"><b>${fmtK(s.best)}</b><br><span class="cls">${esc(s.best_when)}</span></td><td class="num">${fmtK(s.last)}<br><span class="cls">${esc(s.last_when)}</span></td>
      <td class="num">${fmtK(s.avg5)}</td><td class="num ${s.trend > 0 ? "good" : s.trend < 0 ? "bad" : ""}">${s.trend != null ? (s.trend > 0 ? "+" : s.trend < 0 ? "−" : "±") + fmtK(Math.abs(s.trend)) : "–"}</td>
      <td class="bench-cell"><input type="text" inputmode="numeric" data-bench-dps="${esc(s.prof)}" value="${s.bench ? s.bench : ""}" placeholder="Ziel-DPS"><input type="text" data-bench-label="${esc(s.prof)}" value="${esc(s.bench_label)}" placeholder="Build, z. B. Power"><button class="btn small" data-bench-save="${esc(s.prof)}">Speichern</button></td>
      <td>${meter(s.pct_best)}</td><td>${meter(s.pct_avg5)}</td></tr>`).join("");
  const sel = d.specs.find((s) => s.key === S.golem.key);
  const atts = d.attempts.filter((a) => a.acc + "|" + a.prof === sel.key);
  const arows = atts.slice().reverse().map((a) => `<tr><td>${esc(a.when)}</td><td>${esc(a.golem)}</td><td class="num">${esc(a.dur_txt)}${a.kill ? "" : ` <span class="cls">(${a.hp_left} % übrig)</span>`}</td>
      <td class="num"><b>${fmtK(a.dps)}</b>${a.dps === sel.best ? ' <span class="good">★</span>' : ""}</td><td>${meter(a.pct)}</td>
      <td class="num">${a.quick} %</td><td class="num">${a.alac} %</td><td class="num">${String(a.might).replace(".", DEC)}</td>
      <td>${a.food ? "" : '<span class="bad">kein Food</span> '}${a.util ? "" : '<span class="bad">kein Utility</span>'}${a.food && a.util ? '<span class="good">✔</span>' : ""}</td>
      <td>${a.rot && atts.length > 1 ? `<a href="#" data-grot="${esc(a.id)}" data-gacc="${esc(a.acc)}" style="color:var(--accent)">Rotation</a>` : ""}</td></tr>`).join("");
  body.innerHTML = `
    <div class="card scroll"><h3>Deine Specs am Golem</h3><table><tr><th>Spec</th><th class="num">Versuche</th><th class="num">Bestwert</th><th class="num">Letzter</th><th class="num">Ø letzte 5</th><th class="num">Trend</th><th>Benchmark-Ziel</th><th>Bestwert vs. Ziel</th><th>Ø 5 vs. Ziel</th></tr>${rows}</table>
      <div class="legend">Boss-DPS am Golem (Schaden aufs Ziel / Kampfdauer) · Trend = Ø der letzten 5 gegen die 5 davor · Ziel-DPS pro Spec selbst eintragen, z. B. den Benchmark von Snow Crows (Knopf oben) – der weiße Strich im Balken ist 100 % · Klick auf eine Zeile zeigt alle Versuche</div></div>
    <div class="card"><h3>${esc(sel.prof)} · ${esc(sel.name)}${sel.bench ? ` <span class="cls">Ziel ${fmtK(sel.bench)}${sel.bench_label ? " · " + esc(sel.bench_label) : ""}</span>` : ""}</h3>${golemChart(atts, sel)}
      <div class="legend">Gold = DPS pro Versuch · grau gestrichelt = Benchmark-Ziel · dünn gold = Bestwert · grün = über dem Ziel, rot = darunter</div></div>
    <div id="golem-rot"></div>
    <div class="card scroll"><h3>Alle Versuche</h3><table><tr><th>Wann</th><th>Golem</th><th class="num">Dauer</th><th class="num">DPS</th><th>vs. Ziel</th><th class="num">Quickness</th><th class="num">Alacrity</th><th class="num">Might Ø</th><th>Food / Utility</th><th></th></tr>${arows}</table>
      <div class="legend">★ = Bestwert · Boons als Uptime · „Rotation“ vergleicht den Versuch mit deinem besten ${esc(sel.prof)}-Versuch (gleicher Golem bevorzugt)</div></div>`;
  $$("[data-gk]", body).forEach((tr) => tr.onclick = (ev) => { if (ev.target.closest("input,button")) return; S.golem.key = tr.dataset.gk; renderGolem(); });
  $$("[data-bench-save]", body).forEach((b) => b.onclick = async () => {
    const prof = b.dataset.benchSave; const row = b.closest("td");
    try {
      await api("/api/golem/bench", { prof, dps: $("[data-bench-dps]", row).value.trim(), label: $("[data-bench-label]", row).value });
      S.settings = await api("/api/settings"); toast("Ziel gespeichert"); loadGolem(true);
    } catch (e) { toast(e.message); }
  });
  $$("[data-bench-dps]", body).forEach((i) => i.onkeydown = (ev) => { if (ev.key === "Enter") $("[data-bench-save]", i.closest("td")).click(); });
  $$("[data-grot]", body).forEach((a) => a.onclick = (ev) => { ev.preventDefault(); showGolemRotation(a.dataset.grot, a.dataset.gacc); });
}
function golemChart(atts, sel) {
  if (!atts.length) return "";
  const W = 900, H = 240, PL = 56, PR = 120, PT = 20, PB = 30;
  const vals = atts.map((a) => a.dps).concat(sel.bench ? [sel.bench] : []);
  const span = Math.max(...vals) - Math.min(...vals) || 2000;
  const max = Math.max(...vals) + span * 0.15, min = Math.max(0, Math.min(...vals) - span * 0.15);
  const x = (i) => PL + (atts.length === 1 ? (W - PL - PR) / 2 : i * (W - PL - PR) / (atts.length - 1));
  const y = (v) => PT + (max - v) / (max - min) * (H - PT - PB);
  const line = atts.length === 1 ? `M${x(0) - 18},${y(atts[0].dps)}L${x(0) + 18},${y(atts[0].dps)}` : atts.map((a, i) => `${i ? "L" : "M"}${x(i)},${y(a.dps)}`).join("");
  let svg = "";
  if (sel.bench) {
    const yb = y(sel.bench), xa = atts.length === 1 ? x(0) - 18 : x(0), xb = atts.length === 1 ? x(0) + 18 : x(atts.length - 1);
    const area = `${line}L${xb},${yb}L${xa},${yb}Z`; const id = "g" + Math.random().toString(36).slice(2, 8);
    svg += `<defs><clipPath id="${id}a"><rect x="0" y="0" width="${W}" height="${yb}"/></clipPath><clipPath id="${id}b"><rect x="0" y="${yb}" width="${W}" height="${H}"/></clipPath></defs>
      <path d="${area}" fill="var(--ok)" opacity=".18" clip-path="url(#${id}a)"/><path d="${area}" fill="var(--bad)" opacity=".16" clip-path="url(#${id}b)"/>
      <line x1="${PL}" x2="${W - PR}" y1="${yb}" y2="${yb}" stroke="var(--muted)" stroke-width="2" stroke-dasharray="6 5"/><text x="${W - PR + 6}" y="${yb + 4}" fill="var(--muted)">Ziel ${fmtK(sel.bench)}</text>`;
  }
  if (atts.length > 1) { const yb = y(sel.best); svg += `<line x1="${PL}" x2="${W - PR}" y1="${yb}" y2="${yb}" stroke="var(--accent)" stroke-width="1" opacity=".7"/><text x="${W - PR + 6}" y="${yb + (sel.bench && Math.abs(y(sel.bench) - yb) < 14 ? -8 : 4)}" fill="var(--accent)">Best ${fmtK(sel.best)}</text>`; }
  for (let k = 0; k <= 3; k++) { const v = min + (max - min) * k / 3; svg += `<text x="${PL - 6}" y="${y(v) + 4}" text-anchor="end" fill="var(--muted)">${fmtK(v)}</text>`; }
  svg += `<path d="${line}" fill="none" stroke="var(--accent)" stroke-width="2.5"/>`;
  const step = Math.max(1, Math.ceil(atts.length / 8));
  atts.forEach((a, i) => {
    svg += `<circle cx="${x(i)}" cy="${y(a.dps)}" r="3.5" fill="var(--accent)"><title>${esc(a.when)} · ${fmtK(a.dps)}${a.pct != null ? " · " + a.pct + " % vom Ziel" : ""}</title></circle>`;
    if (i % step === 0 || i === atts.length - 1) svg += `<text x="${x(i)}" y="${H - 8}" text-anchor="middle" fill="var(--muted)">${esc(a.when.slice(0, 5))}</text>`;
  });
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" width="100%">${svg}</svg>`;
}
async function showGolemRotation(id, acc) {
  const out = $("#golem-rot");
  out.innerHTML = `<div class="card"><h3>Rotation</h3><div class="status"><span class="spin"></span>Vergleiche …</div></div>`;
  out.scrollIntoView({ behavior: "smooth", block: "nearest" });
  try {
    const r = await job("/api/golem/rotation", { log: id, acc }, out.querySelector(".status"));
    const rows = r.rows.map((x) => `<tr><td>${esc(x.name)}</td><td class="num">${de1(x.ours)}</td><td class="num">${de1(x.top)}</td><td class="num ${x.tone}">${x.diff > 0 ? "+" : x.diff < 0 ? "−" : "±"}${de1(Math.abs(x.diff))}</td><td>${x.missing ? '<span class="bad">fehlt</span>' : ""}</td></tr>`).join("");
    out.innerHTML = `<div class="card"><h3>Rotation: ${esc(r.prof)} am ${esc(r.golem)} gegen ${esc(r.ref_kind)}</h3>
      <div class="kpis">${kpiBox("DPS", esc(r.ours_dps), "Vergleich " + r.top_dps)}${kpiBox("Casts pro Minute", de1(r.ours_cpm), "Vergleich " + de1(r.top_cpm))}${kpiBox("Zeit in Animation", r.ours_anim != null ? Math.round(r.ours_anim) + " %" : "–", r.top_anim != null ? "Vergleich " + Math.round(r.top_anim) + " %" : "")}${kpiBox("Dauer", esc(r.ours_dur), "Vergleich " + r.top_dur)}</div>
      ${r.notes.length ? `<ul style="margin:0 0 10px">${r.notes.map((n) => `<li>${n}</li>`).join("")}</ul>` : ""}
      <table><tr><th>Skill</th><th class="num">Dieser Versuch / Minute</th><th class="num">Vergleich / Minute</th><th class="num">Differenz</th><th></th></tr>${rows}</table>
      <div class="legend">Vergleich: ${esc(r.ref_kind)} vom ${esc(r.ref_when)} (${esc(r.ref_golem)}). Casts pro Minute über den ganzen Versuch · Sigil-, Relikt- und Trait-Procs ausgeblendet.</div></div>`;
  } catch (er) { out.innerHTML = `<div class="card"><h3>Rotation</h3><div class="status err">${esc(er.message)}</div></div>`; }
}

/* ---------------- Start ---------------- */
(async function init() {
  try { const p = await api("/api/ping"); $("#version").textContent = "Version " + p.version; } catch {}
  S.settings = await api("/api/settings");
  setInterval(() => api("/api/ping").catch(() => {}), 10000);
  $("#gw2-result").innerHTML = `<div class="empty"><h2>Bereit</h2><p>Wähle einen Abend und klicke auf „Analysieren“. Die Auswertung läuft komplett lokal – ohne KI.</p></div>`;
  $("#loa-result").innerHTML = `<div class="empty"><h2>Bereit</h2><p>Wähle einen Tag aus LOA Logs und klicke auf „Analysieren“.</p></div>`;
  gw2Scan(); loaDays(); checkUpdate();
})();
